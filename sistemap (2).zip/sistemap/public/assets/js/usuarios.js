// Usuarios page JS
(function(){
  const mensaje = document.getElementById('mensaje-alerta');
  // Modal helpers
  let currentForm = null; let eliminarUsuario = false;
  function closeModal(){ const m=document.getElementById('confirmModal'); if(m){ m.style.display='none'; } currentForm=null; eliminarUsuario=false; }
  function showModal(message, form, isDelete=false){ currentForm=form; eliminarUsuario=isDelete; const mm=document.getElementById('modalMessage'); if(mm) mm.textContent=message; const m=document.getElementById('confirmModal'); if(m){ m.style.display='block'; } }
  window.closeModal = closeModal; window.confirmarEliminacion = function(form){ showModal('¿Estás seguro de que deseas eliminar este usuario?', form, true); }

  // Enlazar botón Editar por fila para cargar en el formulario superior
  document.addEventListener('click', function(e){
    const t = e.target;
    if (t && t.classList && t.classList.contains('btn-editar-usuario')) {
      const data = t.getAttribute('data-usuario');
      try { const u = JSON.parse(data); window.editarUsuario(u); } catch(_){ }
    }
  });

  // Crear/Editar usuario desde formulario superior
  const formAgregar = document.getElementById('form-agregar-usuario');
  if (formAgregar) {
    // Funciones para editar/cancelar
    window.editarUsuario = function(usuario){
      const idInput = document.getElementById('usuario_id');
      const uInput = document.getElementById('usuario');
      const rSelect = document.getElementById('rol');
      const pInput = document.getElementById('contrasena');
      const btnCancelar = document.getElementById('btnCancelarUsuario');
      const btnGuardar = document.getElementById('btnGuardarUsuario');
      if (idInput && uInput && rSelect && pInput) {
        idInput.value = usuario.id;
        uInput.value = (usuario.usuario||'').toUpperCase();
        rSelect.value = usuario.rol || 'tecnico';
        pInput.value = '';
        try { pInput.required = false; } catch(_){ pInput.removeAttribute && pInput.removeAttribute('required'); }
        formAgregar.action = '/sistemap/public/usuarios/update';
        if (btnGuardar) btnGuardar.textContent = 'Actualizar Usuario';
        if (btnCancelar) btnCancelar.style.display = 'inline';
      }
    }
    const btnCancelar = document.getElementById('btnCancelarUsuario');
    if (btnCancelar) btnCancelar.addEventListener('click', function(){
      formAgregar.reset();
      const idInput = document.getElementById('usuario_id'); if (idInput) idInput.value = '';
      formAgregar.action = '/sistemap/public/usuarios/store';
      const btnGuardar = document.getElementById('btnGuardarUsuario'); if (btnGuardar) btnGuardar.textContent = 'Guardar Usuario';
      const pInput = document.getElementById('contrasena'); if (pInput) { try { pInput.required = true; } catch(_){ pInput.setAttribute && pInput.setAttribute('required','required'); } }
      this.style.display = 'none';
    });

    // Envío con validaciones (crear/editar)
    formAgregar.addEventListener('submit', function(e){
      e.preventDefault();
      const msg = document.getElementById('mensaje-alerta');
      const fd = new FormData(this);
      const usuario = String(fd.get('usuario')||'').toUpperCase().trim();
      const contrasena = String(fd.get('contrasena')||'').trim();
      const rol = String(fd.get('rol')||'').trim();
      const isUpdate = (this.action||'').endsWith('/update');
      if (!isUpdate && (!usuario || !rol || !contrasena)) {
        msg.style.display='block'; msg.style.backgroundColor='#f8d7da'; msg.style.color='#721c24';
        msg.innerHTML = '❌ Complete todos los campos obligatorios.' + '<button class="btn-cerrar-alerta" style="position:absolute; top:5px; right:10px; background:none; border:none; font-size:18px;">&times;</button>';
        return;
      }
      if (usuario && !/^[A-ZÁÉÍÓÚÑÜ]+$/u.test(usuario)) {
        msg.style.display='block'; msg.style.backgroundColor='#f8d7da'; msg.style.color='#721c24';
        msg.innerHTML = '❌ El nombre de usuario solo debe contener letras (sin espacios).' + '<button class="btn-cerrar-alerta" style="position:absolute; top:5px; right:10px; background:none; border:none; font-size:18px;">&times;</button>';
        return;
      }
      const tieneLetra = /[A-Za-z]/.test(contrasena);
      const tieneNumero = /[0-9]/.test(contrasena);
      if (!isUpdate && !(contrasena.length >= 10 && tieneLetra && tieneNumero)) {
        msg.style.display='block'; msg.style.backgroundColor='#f8d7da'; msg.style.color='#721c24';
        msg.innerHTML = '❌ La contraseña debe tener mínimo 10 caracteres y combinar letras y números.' + '<button class="btn-cerrar-alerta" style="position:absolute; top:5px; right:10px; background:none; border:none; font-size:18px;">&times;</button>';
        return;
      }
      if (isUpdate && contrasena && contrasena.length > 0 && !(contrasena.length >= 10 && tieneLetra && tieneNumero)) {
        msg.style.display='block'; msg.style.backgroundColor='#f8d7da'; msg.style.color='#721c24';
        msg.innerHTML = '❌ La contraseña debe tener mínimo 10 caracteres y combinar letras y números.' + '<button class="btn-cerrar-alerta" style="position:absolute; top:5px; right:10px; background:none; border:none; font-size:18px;">&times;</button>';
        return;
      }
      // Normalizar
      fd.set('usuario', usuario);
      appendCsrf(fd);
      // El formulario ya incluye _csrf como input hidden
      // Debug: log de payload (sin contraseña)
      try { const debugFd = new FormData(this); debugFd.delete('contrasena'); console.debug('POST usuarios payload:', Object.fromEntries(debugFd.entries())); } catch(_){ }
      fetch(this.action || '/sistemap/public/usuarios/store', { method:'POST', body: fd, headers: { 'Accept': 'application/json' } })
        .then(async r=>{
          const raw = await r.text();
          let data = null;
          try { data = raw ? JSON.parse(raw) : null; } catch(_) { /* no JSON */ }
          if (!r.ok) {
            const err = (data && (data.error||data.message)) || (raw ? raw.substring(0,300) : 'Error');
            throw new Error(err);
          }
          if (!data) { throw new Error(raw ? raw.substring(0,300) : 'Respuesta vacía del servidor'); }
          return data;
        })
        .then(res=>{
          msg.style.display='block';
          if (!res.success) {
            try { console.error('Usuarios/store|update error response:', res); } catch(_){ }
            msg.style.backgroundColor='#f8d7da'; msg.style.color='#721c24';
            const detalle = res.error || res.message || 'Error al procesar la solicitud.';
            msg.innerHTML = `❌ ${detalle}` + '<button class="btn-cerrar-alerta" style="position:absolute; top:5px; right:10px; background:none; border:none; font-size:18px;">&times;</button>';
          } else {
            msg.style.backgroundColor='#d4edda'; msg.style.color='#155724';
            msg.innerHTML = `✅ ${isUpdate ? 'Usuario actualizado correctamente.' : 'Usuario agregado exitosamente.'}` + '<button class="btn-cerrar-alerta" style="position:absolute; top:5px; right:10px; background:none; border:none; font-size:18px;">&times;</button>';
            this.reset();
            const idInput = document.getElementById('usuario_id'); if (idInput) idInput.value = '';
            const btnCancelar = document.getElementById('btnCancelarUsuario'); if (btnCancelar) btnCancelar.style.display='none';
            const btnGuardar = document.getElementById('btnGuardarUsuario'); if (btnGuardar) btnGuardar.textContent='Guardar Usuario';
            setTimeout(()=>location.reload(), 1000);
          }
        })
        .catch(err=>{
          msg.style.display='block'; msg.style.backgroundColor='#f8d7da'; msg.style.color='#721c24';
          msg.innerHTML = `❌ ${(err && err.message) ? err.message : 'Ocurrió un error al registrar. Verifique conexión y permisos.'}` + '<button class="btn-cerrar-alerta" style="position:absolute; top:5px; right:10px; background:none; border:none; font-size:18px;">&times;</button>';
        })
        .finally(()=>{
          document.querySelectorAll('#mensaje-alerta .btn-cerrar-alerta').forEach(b=> b.addEventListener('click', function(){ this.parentElement.style.display='none'; }));
        });
    });
  }

  // Descargar PDF de usuarios
  const btnPdfUsuarios = document.getElementById('btn-descargar-usuarios');
  if (btnPdfUsuarios) btnPdfUsuarios.addEventListener('click', function(){
    const jsPDF = window.jspdf && window.jspdf.jsPDF;
    if (!jsPDF) return;
    const doc = new jsPDF();
    doc.text('Listado de Usuarios', 14, 15);
    const table = document.querySelector('#tabla-usuarios');
    if (!table) return;
    const headers = Array.from(table.querySelectorAll('thead th')).map(th=> (th.textContent||'').trim());
    let excludeIdx = headers.findIndex(h=> h.toLowerCase() === 'acciones');
    if (excludeIdx < 0 && headers.length>0) excludeIdx = headers.length - 1; // fallback: última
    const head = [ headers.filter((_,i)=> i !== excludeIdx) ];
    const body = Array.from(table.querySelectorAll('tbody tr')).map(tr => {
      const cells = Array.from(tr.children).map(td => (td.textContent||'').trim());
      return cells.filter((_,i)=> i !== excludeIdx);
    });
    doc.autoTable({ head, body, startY: 20 });
    doc.save('usuarios.pdf');
  });

  // Cerrar modal con nuevos ids (X y Cancelar)
  const closeX = document.getElementById('closeModalX');
  if (closeX) closeX.addEventListener('click', function(){ closeModal(); });
  const cancelModal = document.getElementById('cancelModal');
  if (cancelModal) cancelModal.addEventListener('click', function(){ closeModal(); });

  // Enlazar botones eliminar a modal
  document.querySelectorAll('.btn-eliminar-usuario').forEach(btn => {
    btn.addEventListener('click', function(e){ e.preventDefault(); showModal('¿Estás seguro de que deseas eliminar este usuario?', this.closest('form'), true); });
  });

  // Confirmación (update/delete)
  const confirmBtn = document.getElementById('confirmBtn');
  if (confirmBtn) {
    confirmBtn.addEventListener('click', function(){
      if (!currentForm) return;
      // Normalizar mayúsculas
      const inputUsuario = currentForm.querySelector('input[name="usuario"]');
      if (inputUsuario && inputUsuario.value) inputUsuario.value = inputUsuario.value.toUpperCase();
      const fd = new FormData(currentForm); appendCsrf(fd);
      fetch(currentForm.action, { method:'POST', body: fd })
        .then(res => res.json()).then(data => {
          if (!mensaje) return;
          mensaje.style.display='block';
          mensaje.style.backgroundColor = data.success ? '#d4edda' : '#f8d7da';
          mensaje.style.color = data.success ? '#155724' : '#721c24';
          mensaje.innerHTML = `${data.success ? '✅' : '❌'} ${data.message || data.error}` +
            '<button onclick="this.parentElement.style.display=\'none\'" style="position:absolute; top:5px; right:10px; background:none; border:none; font-size:18px;">&times;</button>';
          if (data.success) setTimeout(()=>location.reload(), 1200);
        });
      closeModal();
    });
  }

  // Normalizar acciones de formularios de eliminar según BASE para evitar 404
  try {
    document.querySelectorAll('form[action*="/usuarios/delete"]').forEach(f=>{ f.action = '/sistemap/public/usuarios/delete'; });
  } catch(_){}

  
})();
