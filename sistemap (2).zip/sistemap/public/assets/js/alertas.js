(function(){
  let ultimoHistorial = { alertaId: null, filas: [] };
  function cargarAlertas(){
    const estadoSel = document.getElementById('filtro-estado-alertas');
    const estado = estadoSel ? (estadoSel.value || '') : '';
    const url = '/sistemap/public/alertas/list' + (estado ? ('?estado=' + encodeURIComponent(estado)) : '');
    fetch(url)
      .then(r=>r.json())
      .then(data=>{
        const tbody = document.querySelector('#tabla-alertas tbody');
        if (!tbody) return;
        tbody.innerHTML = '';
        if (data.success) {
          data.data.forEach(alerta => {
            const fila = document.createElement('tr');
            const nivel = (alerta.nivel || 'info').toLowerCase();
            const claseNivel = ['peligro','cuidado','info'].includes(nivel) ? nivel : 'info';
            const mensaje = alerta.mensaje || 'Sin mensaje';
            const ubicacion = alerta.ubicacion || 'No especificada';
            const numeroSerie = alerta.numero_serie || '';
            const numeroRFID = alerta.numero_tarjeta_rfid || '';
            const fecha = alerta.fecha || 'Desconocida';
            const estado = alerta.estado_alerta || 'NO ATENDIDO';
            fila.className = claseNivel;
            const esNoAtendido = estado.toUpperCase()==='NO ATENDIDO';
            const btnAtender = esNoAtendido ? `<button class="btn-atender" data-id="${alerta.id}">ATENDER</button>` : '';
            const btnRevertir = !esNoAtendido ? `<button class="btn-revertir" data-id="${alerta.id}">REVERTIR</button>` : '';
            const btnHist = `<button class="btn-historial" data-id="${alerta.id}">HISTORIAL</button>`;
            fila.innerHTML = `<td>${alerta.id}</td><td>${mensaje}</td><td>${numeroRFID}</td><td>${numeroSerie}</td><td>${ubicacion}</td><td>${estado}</td><td>${fecha}</td><td>${btnAtender} ${btnRevertir} ${btnHist}</td>`;
            tbody.appendChild(fila);
          });

  // Descargar PDF de la lista de alertas
  const btnPdfAlertas = document.getElementById('btn-descargar-alertas-lista');
  if (btnPdfAlertas) btnPdfAlertas.addEventListener('click', function(){
    const jsPDF = window.jspdf && window.jspdf.jsPDF;
    if (!jsPDF) return;
    const doc = new jsPDF();
    doc.text('Listado de Alertas', 14, 15);
    const table = document.querySelector('#tabla-alertas');
    if (!table) return;
    const headers = Array.from(table.querySelectorAll('thead th')).map(th=> (th.textContent||'').trim());
    let excludeIdx = headers.findIndex(h=> h.toLowerCase() === 'acciones');
    if (excludeIdx < 0 && headers.length>0) excludeIdx = headers.length - 1; // fallback: última
    const head = [ headers.filter((_,i)=> i !== excludeIdx) ];
    const body = Array.from(table.querySelectorAll('tbody tr')).map(tr => {
      const cells = Array.from(tr.children).map(td => (td.textContent||'').trim());
      return cells.filter((_,i)=> i !== excludeIdx);
    });
    doc.autoTable({ head, body, startY: 20 });
    doc.save('alertas.pdf');
  });
        }
      })
      .catch(console.error);
  }
  cargarAlertas();
  setInterval(cargarAlertas, 500);
  const estadoSel = document.getElementById('filtro-estado-alertas');
  if (estadoSel) estadoSel.addEventListener('change', cargarAlertas);

  // Delegación para marcar como ATENDIDA
  document.addEventListener('click', function(e){
    const t = e.target;
    if (t && t.classList.contains('btn-atender')) {
      const id = t.getAttribute('data-id');
      const fd = new FormData();
      fd.set('id', id);
      appendCsrf(fd);
      fetch('/sistemap/public/alertas/atender', { method:'POST', body: fd })
        .then(r=>r.json())
        .then(resp=>{ if (resp.success) { cargarAlertas(); } });
    }
    if (t && t.classList.contains('btn-revertir')) {
      const id = t.getAttribute('data-id');
      const fd = new FormData();
      fd.set('id', id);
      appendCsrf(fd);
      fetch('/sistemap/public/alertas/revertir', { method:'POST', body: fd })
        .then(r=>r.json())
        .then(resp=>{ if (resp.success) { cargarAlertas(); } });
    }
    if (t && t.classList.contains('btn-historial')) {
      const id = t.getAttribute('data-id');
      fetch('/sistemap/public/alertas/historial?id=' + encodeURIComponent(id))
        .then(r=>r.json())
        .then(resp=>{
          if (resp.success) {
            const cont = document.getElementById('historialContenido');
            const rows = resp.data.map(h => `<tr><td>${h.fecha}</td><td>${h.estado}</td><td>${h.usuario||''}</td></tr>`).join('');
            cont.innerHTML = `<table style=\"width:100%; border-collapse:collapse;\"><thead><tr><th>Fecha</th><th>Estado</th><th>Usuario</th></tr></thead><tbody>${rows||'<tr><td colspan=\"3\">Sin historial</td></tr>'}</tbody></table>`;
            // Guardar para exportación
            ultimoHistorial.alertaId = id;
            ultimoHistorial.filas = resp.data || [];
            document.getElementById('historialModal').style.display = 'block';
          }
        });
    }
  });

  // Cerrar modal de historial
  document.addEventListener('click', function(e){
    if (e.target && e.target.id === 'cerrarHistorial') {
      document.getElementById('historialModal').style.display = 'none';
    }
    if (e.target && e.target.id === 'exportarHistorialPDF') {
      const jsPDF = window.jspdf && window.jspdf.jsPDF;
      if (!jsPDF) return;
      const doc = new jsPDF();
      const titulo = `Historial Alerta #${ultimoHistorial.alertaId||''}`;
      doc.text(titulo, 14, 15);
      const body = (ultimoHistorial.filas||[]).map(h=>[h.fecha, h.estado, h.usuario||'']);
      doc.autoTable({
        head: [['Fecha','Estado','Usuario']],
        body: body.length ? body : [['-','-','-']],
        startY: 20
      });
      doc.save(`historial_alerta_${ultimoHistorial.alertaId||'N'}.pdf`);
    }
  });
})();
