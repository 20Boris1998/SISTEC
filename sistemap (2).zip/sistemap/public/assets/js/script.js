document.addEventListener('DOMContentLoaded', () => {
  console.log('SISTEC iniciado correctamente.');

  // Evitar que la app se incruste en iframes
  try { if (window.top !== window.self) { window.top.location = window.location; } } catch (_) {}

  // Convierte a MAYÚSCULAS en tiempo real solo inputs con clase .to-upper
  document.body.addEventListener('input', (e) => {
    const el = e.target;
    if (el && el.classList && el.classList.contains('to-upper')) {
      if (el.tagName === 'INPUT' && el.type !== 'password') {
        el.value = el.value.toUpperCase();
      }
      if (el.tagName === 'TEXTAREA') {
        el.value = el.value.toUpperCase();
      }
    }
  });

  // CSRF helpers
  window.getCsrfToken = function() {
    const meta = document.querySelector('meta[name="csrf-token"]');
    return meta ? meta.getAttribute('content') : '';
  }
  window.appendCsrf = function(fd) {
    const t = window.getCsrfToken();
    if (t && fd && typeof fd.set === 'function') { fd.set('_csrf', t); }
    return fd;
  }
});
