(function(){
  let currentForm = null;

  window.editarEquipo = function(equipo){
    document.getElementById('equipo_id').value = equipo.id;
    document.getElementById('numero_tarjeta_rfid').value = (equipo.numero_tarjeta_rfid||'').toString().toUpperCase();
    document.getElementById('nombre').value = (equipo.nombre||'').toString().toUpperCase();
    document.getElementById('numero_serie').value = (equipo.numero_serie||'').toString().toUpperCase();
    document.getElementById('ubicacion').value = (equipo.ubicacion||'').toString().toUpperCase();

    document.getElementById('formEquipo').action = "/sistemap/public/equipos/update";
    document.getElementById('btnGuardar').textContent = "Actualizar Equipo";
    document.getElementById('btnCancelar').style.display = "inline";
  }

  window.cancelarEdicion = function(){
    document.getElementById('formEquipo').reset();
    document.getElementById('formEquipo').action = "/sistemap/public/equipos/store";
    document.getElementById('btnGuardar').textContent = "Guardar Equipo";
    document.getElementById('btnCancelar').style.display = "none";
  }

  function closeModal(){
    document.getElementById('confirmModal').style.display = 'none';
    currentForm = null;
  }
  window.closeModal = closeModal;

  function showModal(message, form){
    currentForm = form;
    document.getElementById('modalMessage').textContent = message;
    document.getElementById('confirmModal').style.display = 'block';
  }
  window.confirmarEliminacion = function(form){ showModal('¿Estás seguro de que deseas eliminar este equipo?', form); }

  const confirmBtn = document.getElementById('confirmBtn');
  if (confirmBtn) confirmBtn.addEventListener('click', function(){
    const mensaje = document.getElementById('mensaje-alerta');
    if (currentForm) {
      const fd = new FormData(currentForm);
      appendCsrf(fd);
      fetch(currentForm.action, { method:'POST', body: fd })
        .then(res => res.json())
        .then(res => {
          mensaje.style.display = 'block';
          if (!res.success) {
            mensaje.style.backgroundColor = '#f8d7da';
            mensaje.style.color = '#721c24';
            mensaje.innerHTML = `❌ ${res.error || 'Error'}` +
              '<button onclick="this.parentElement.style.display=\'none\'" style="position:absolute; top:5px; right:10px; background:none; border:none; font-size:18px;">&times;</button>';
          } else {
            mensaje.style.backgroundColor = '#d4edda';
            mensaje.style.color = '#155724';
            mensaje.innerHTML = `✅ Operación realizada correctamente.` +
              '<button onclick="this.parentElement.style.display=\'none\'" style="position:absolute; top:5px; right:10px; background:none; border:none; font-size:18px;">&times;</button>';
            setTimeout(() => location.reload(), 1200);
          }
        });
    }
    closeModal();
  });

  // Descargar PDF de la tabla de gestión
  const btnPdf = document.getElementById('btn-descargar-equipos-gestion');
  if (btnPdf) btnPdf.addEventListener('click', function(){
    const jsPDF = window.jspdf && window.jspdf.jsPDF;
    if (!jsPDF) return;
    const doc = new jsPDF();
    doc.text('Listado de Equipos', 14, 15);
    const table = document.querySelector('#tabla-equipos-gestion');
    if (!table) return;
    const headers = Array.from(table.querySelectorAll('thead th')).map(th=> (th.textContent||'').trim());
    let excludeIdx = headers.findIndex(h=> h.toLowerCase() === 'acciones');
    if (excludeIdx < 0 && headers.length>0) excludeIdx = headers.length - 1; // fallback
    const head = [ headers.filter((_,i)=> i !== excludeIdx) ];
    const body = Array.from(table.querySelectorAll('tbody tr')).map(tr => {
      const cells = Array.from(tr.children).map(td => (td.textContent||'').trim());
      return cells.filter((_,i)=> i !== excludeIdx);
    });
    doc.autoTable({ head, body, startY: 20 });
    doc.save('equipos.pdf');
  });

  // Cancelar modal sin inline
  const cancelBtn = document.getElementById('btnCancelar');
  if (cancelBtn) cancelBtn.addEventListener('click', function(){ cancelarEdicion(); });

  const closeX = document.getElementById('closeModalX');
  if (closeX) closeX.addEventListener('click', function(){ closeModal(); });
  const cancelModal = document.getElementById('cancelModal');
  if (cancelModal) cancelModal.addEventListener('click', function(){ closeModal(); });

  const formEquipo = document.getElementById('formEquipo');
  formEquipo.addEventListener('submit', function(e){
    e.preventDefault();
    const mensaje = document.getElementById('mensaje-alerta');
    const formData = new FormData(this);
    const isUpdate = this.action.endsWith('/update');
    // Validaciones frontend
    const rfid = String(formData.get('numero_tarjeta_rfid')||'').toUpperCase();
    const nombre = String(formData.get('nombre')||'').toUpperCase();
    const numeroSerie = String(formData.get('numero_serie')||'').toUpperCase();
    const ubicacion = String(formData.get('ubicacion')||'').toUpperCase();
    if (!isUpdate && (!rfid || !nombre || !numeroSerie || !ubicacion)) {
      mensaje.style.display = 'block'; mensaje.style.backgroundColor = '#f8d7da'; mensaje.style.color = '#721c24';
      mensaje.innerHTML = '❌ Complete todos los campos obligatorios.' + '<button onclick="this.parentElement.style.display=\'none\'" style="position:absolute; top:5px; right:10px; background:none; border:none; font-size:18px;">&times;</button>';
      return;
    }
    if (rfid && !/^[A-Z0-9]+$/.test(rfid)) {
      mensaje.style.display = 'block'; mensaje.style.backgroundColor = '#f8d7da'; mensaje.style.color = '#721c24';
      mensaje.innerHTML = '❌ El RFID debe ser alfanumérico (sin espacios).'+ '<button onclick="this.parentElement.style.display=\'none\'" style="position:absolute; top:5px; right:10px; background:none; border:none; font-size:18px;">&times;</button>';
      return;
    }
    if (nombre && !/^[A-ZÁÉÍÓÚÑÜ ]+$/u.test(nombre)) {
      mensaje.style.display = 'block'; mensaje.style.backgroundColor = '#f8d7da'; mensaje.style.color = '#721c24';
      mensaje.innerHTML = '❌ El nombre del equipo solo debe contener letras y espacios.'+ '<button onclick="this.parentElement.style.display=\'none\'" style="position:absolute; top:5px; right:10px; background:none; border:none; font-size:18px;">&times;</button>';
      return;
    }
    if (numeroSerie && !/^[A-Z0-9-]+$/.test(numeroSerie)) {
      mensaje.style.display = 'block'; mensaje.style.backgroundColor = '#f8d7da'; mensaje.style.color = '#721c24';
      mensaje.innerHTML = '❌ El número de serie solo puede tener letras, números y guiones.'+ '<button onclick="this.parentElement.style.display=\'none\'" style="position:absolute; top:5px; right:10px; background:none; border:none; font-size:18px;">&times;</button>';
      return;
    }
    if (ubicacion && !/^LABORATORIO\s+\d{3}$/.test(ubicacion)) {
      mensaje.style.display = 'block'; mensaje.style.backgroundColor = '#f8d7da'; mensaje.style.color = '#721c24';
      mensaje.innerHTML = '❌ Ubicación inválida. Ejemplo válido: LABORATORIO 101'+ '<button onclick="this.parentElement.style.display=\'none\'" style="position:absolute; top:5px; right:10px; background:none; border:none; font-size:18px;">&times;</button>';
      return;
    }
    // Normalizar a MAYÚSCULAS en frontend
    if (formData.get('numero_tarjeta_rfid')) formData.set('numero_tarjeta_rfid', rfid);
    if (formData.get('nombre')) formData.set('nombre', nombre);
    if (formData.get('numero_serie')) formData.set('numero_serie', numeroSerie);
    if (formData.get('ubicacion')) formData.set('ubicacion', ubicacion);
    appendCsrf(formData);
    // isUpdate calculado arriba
    fetch(this.action, { method:'POST', body: formData })
      .then(res => res.json())
      .then(res => {
        mensaje.style.display='block';
        if (!res.success) {
          mensaje.style.backgroundColor='#f8d7da'; mensaje.style.color='#721c24';
          mensaje.innerHTML = `❌ ${res.error || 'Error'}` + '<button class="btn-cerrar-alerta" style="position:absolute; top:5px; right:10px; background:none; border:none; font-size:18px;">&times;</button>';
        } else {
          mensaje.style.backgroundColor='#d4edda'; mensaje.style.color='#155724';
          mensaje.innerHTML = `✅ ${isUpdate ? 'Equipo actualizado correctamente.' : 'Equipo agregado exitosamente.'}` + '<button class="btn-cerrar-alerta" style="position:absolute; top:5px; right:10px; background:none; border:none; font-size:18px;">&times;</button>';
          this.reset(); cancelarEdicion(); setTimeout(()=>location.reload(), 1200);
        }
      }).then(()=>{
        // Cerrar alerta sin inline
        document.querySelectorAll('#mensaje-alerta .btn-cerrar-alerta').forEach(b=>{
          b.addEventListener('click', function(){ this.parentElement.style.display='none'; });
        })
      });
  });

  // Delegación para botones editar/eliminar
  document.addEventListener('click', function(e){
    const t = e.target;
    if (t && t.classList.contains('btn-editar-equipo')) {
      const data = t.getAttribute('data-equipo');
      try { const equipo = JSON.parse(data); window.editarEquipo(equipo); } catch(_){}
    }
    if (t && t.classList.contains('btn-eliminar-equipo')) {
      e.preventDefault();
      const form = t.closest('form');
      if (form) {
        const mensaje = '¿Estás seguro de que deseas eliminar este equipo?';
        document.getElementById('modalMessage').textContent = mensaje;
        document.getElementById('confirmModal').style.display = 'block';
        currentForm = form;
      }
    }
    if (t && t.classList.contains('btn-cerrar-alerta')) {
      const cont = t.parentElement; if (cont) cont.style.display='none';
    }
  });
})();
