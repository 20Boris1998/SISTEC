(function(){
  // Dependencias: jsPDF y autoTable (cargadas desde CDN en la vista)
  const { jsPDF } = window.jspdf || {};
  let ultimoHistorial = { alertaId: null, filas: [] };

  window.descargarEquiposPDF = function(){
    if (!jsPDF) return;
    const doc = new jsPDF();
    doc.text("Reporte de Equipos Registrados", 14, 15);
    const table = document.querySelector('#tabla-equipos');
    if (!table) return;
    const headers = Array.from(table.querySelectorAll('thead th')).map(th=> (th.textContent||'').trim());
    let excludeIdx = headers.findIndex(h=> h.toLowerCase() === 'acciones');
    if (excludeIdx < 0 && headers.length>0) excludeIdx = headers.length - 1;
    const head = [ headers.filter((_,i)=> i !== excludeIdx) ];
    const body = Array.from(table.querySelectorAll('tbody tr')).map(tr => {
      const cells = Array.from(tr.children).map(td => (td.textContent||'').trim());
      return cells.filter((_,i)=> i !== excludeIdx);
    });
    doc.autoTable({ head, body, startY: 20 });
    doc.save('reporte_equipos.pdf');
  }

  window.descargarAlertasPDF = function(){
    if (!jsPDF) return;
    const doc = new jsPDF();
    const dia = document.getElementById('dia')?.value || '';
    const mes = document.getElementById('mes')?.value || '';
    const anio = document.getElementById('anio')?.value || '';
    const estado = document.getElementById('filtro-estado-reporte')?.value || '';
    const filtroFecha = (dia||mes||anio) ? `Fecha: ${dia||'-'}/${mes||'-'}/${anio||'-'}` : 'Fecha: TODOS';
    const filtroEstado = `Estado: ${estado||'TODOS'}`;
    doc.text("Reporte de Alertas Generadas", 14, 15);
    doc.setFontSize(10);
    doc.text(`${filtroFecha}   |   ${filtroEstado}`, 14, 22);
    doc.setFontSize(12);
    const table = document.querySelector('#tabla-alertas');
    if (!table) return;
    const headers = Array.from(table.querySelectorAll('thead th')).map(th=> (th.textContent||'').trim());
    let excludeIdx = headers.findIndex(h=> h.toLowerCase() === 'acciones');
    if (excludeIdx < 0 && headers.length>0) excludeIdx = headers.length - 1;
    const head = [ headers.filter((_,i)=> i !== excludeIdx) ];
    const body = Array.from(table.querySelectorAll('tbody tr')).map(tr => {
      const cells = Array.from(tr.children).map(td => (td.textContent||'').trim());
      return cells.filter((_,i)=> i !== excludeIdx);
    });
    doc.autoTable({ head, body, startY: 28 });
    doc.save('reporte_alertas.pdf');
  }

  window.descargarPDFCompleto = function(){
    if (!jsPDF) return;
    const doc = new jsPDF();
    const dia = document.getElementById('dia')?.value || '';
    const mes = document.getElementById('mes')?.value || '';
    const anio = document.getElementById('anio')?.value || '';
    const estado = document.getElementById('filtro-estado-reporte')?.value || '';
    const filtroFecha = (dia||mes||anio) ? `Fecha: ${dia||'-'}/${mes||'-'}/${anio||'-'}` : 'Fecha: TODOS';
    const filtroEstado = `Estado: ${estado||'TODOS'}`;
    doc.text("Reporte de Equipos", 14, 15);
    doc.setFontSize(10);
    doc.text(`${filtroFecha}`, 14, 22);
    doc.setFontSize(12);
    const tableEq = document.querySelector('#tabla-equipos');
    if (!tableEq) return;
    const headersEq = Array.from(tableEq.querySelectorAll('thead th')).map(th=> (th.textContent||'').trim());
    let excludeEq = headersEq.findIndex(h=> h.toLowerCase() === 'acciones');
    if (excludeEq < 0 && headersEq.length>0) excludeEq = headersEq.length - 1;
    const headEq = [ headersEq.filter((_,i)=> i !== excludeEq) ];
    const bodyEq = Array.from(tableEq.querySelectorAll('tbody tr')).map(tr => {
      const cells = Array.from(tr.children).map(td => (td.textContent||'').trim());
      return cells.filter((_,i)=> i !== excludeEq);
    });
    doc.autoTable({ head: headEq, body: bodyEq, startY: 28 });

    let y = doc.lastAutoTable.finalY + 10;
    doc.text("Reporte de Alertas", 14, y);
    doc.setFontSize(10);
    y += 7;
    doc.text(`${filtroFecha}   |   ${filtroEstado}`, 14, y);
    doc.setFontSize(12);
    const tableAl = document.querySelector('#tabla-alertas');
    if (!tableAl) return;
    const headersAl = Array.from(tableAl.querySelectorAll('thead th')).map(th=> (th.textContent||'').trim());
    let excludeAl = headersAl.findIndex(h=> h.toLowerCase() === 'acciones');
    if (excludeAl < 0 && headersAl.length>0) excludeAl = headersAl.length - 1;
    const headAl = [ headersAl.filter((_,i)=> i !== excludeAl) ];
    const bodyAl = Array.from(tableAl.querySelectorAll('tbody tr')).map(tr => {
      const cells = Array.from(tr.children).map(td => (td.textContent||'').trim());
      return cells.filter((_,i)=> i !== excludeAl);
    });
    doc.autoTable({ head: headAl, body: bodyAl, startY: y + 5 });

    doc.save('reporte_completo.pdf');
  }

  function actualizarTablas(){
    const dia = document.getElementById('dia')?.value || '';
    const mes = document.getElementById('mes')?.value || '';
    const anio = document.getElementById('anio')?.value || '';
    const estado = document.getElementById('filtro-estado-reporte')?.value || '';
    const params = new URLSearchParams({ dia, mes, anio });
    fetch('/sistemap/public/reportes/equipos?' + params.toString())
      .then(res => res.text())
      .then(html => { const el = document.getElementById('tabla-cuerpo-equipos'); if (el) el.innerHTML = html; });
    const paramsAlertas = new URLSearchParams({ dia, mes, anio });
    if (estado) paramsAlertas.set('estado', estado);
    fetch('/sistemap/public/reportes/alertas?' + paramsAlertas.toString())
      .then(res => res.text())
      .then(html => { const el = document.getElementById('tabla-cuerpo-alertas'); if (el) el.innerHTML = html; });
  }
  window.addEventListener('load', actualizarTablas);
  setInterval(actualizarTablas, 500);
  ['dia','mes','anio'].forEach(id => { const el=document.getElementById(id); if (el) el.addEventListener('input', actualizarTablas); });
  const estadoSel = document.getElementById('filtro-estado-reporte');
  if (estadoSel) estadoSel.addEventListener('change', actualizarTablas);

  // Enlazar botones de descarga
  const btnEquipos = document.getElementById('btn-descargar-equipos');
  if (btnEquipos) btnEquipos.addEventListener('click', descargarEquiposPDF);
  const btnAlertas = document.getElementById('btn-descargar-alertas');
  if (btnAlertas) btnAlertas.addEventListener('click', descargarAlertasPDF);
  const btnCompleto = document.getElementById('btn-descargar-completo');
  if (btnCompleto) btnCompleto.addEventListener('click', descargarPDFCompleto);

  // Delegación para HISTORIAL en tabla de reportes
  document.addEventListener('click', function(e){
    const t = e.target;
    if (t && t.classList && t.classList.contains('btn-historial')) {
      const id = t.getAttribute('data-id');
      fetch('/sistemap/public/alertas/historial?id=' + encodeURIComponent(id))
        .then(r=>r.json())
        .then(resp=>{
          if (resp.success) {
            const cont = document.getElementById('historialContenido');
            const rows = (resp.data||[]).map(h => `<tr><td>${h.fecha}</td><td>${h.estado}</td><td>${h.usuario||''}</td></tr>`).join('');
            cont.innerHTML = `<table style="width:100%; border-collapse:collapse;"><thead><tr><th>Fecha</th><th>Estado</th><th>Usuario</th></tr></thead><tbody>${rows||'<tr><td colspan="3">Sin historial</td></tr>'}</tbody></table>`;
            ultimoHistorial.alertaId = id;
            ultimoHistorial.filas = resp.data || [];
            document.getElementById('historialModal').style.display = 'block';
          }
        });
    }
    if (t && t.id === 'cerrarHistorial') {
      document.getElementById('historialModal').style.display = 'none';
    }
    if (t && t.id === 'exportarHistorialPDF') {
      if (!jsPDF) return;
      const doc = new jsPDF();
      const titulo = `Historial Alerta #${ultimoHistorial.alertaId||''}`;
      doc.text(titulo, 14, 15);
      const body = (ultimoHistorial.filas||[]).map(h=>[h.fecha, h.estado, h.usuario||'']);
      doc.autoTable({ head: [['Fecha','Estado','Usuario']], body: body.length?body:[['-','-','-']], startY: 20 });
      doc.save(`historial_alerta_${ultimoHistorial.alertaId||'N'}.pdf`);
    }
  });
})();
