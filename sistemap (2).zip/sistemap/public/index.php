<?php
// Front Controller
require_once __DIR__ . '/../app/Core/Session.php';
require_once __DIR__ . '/../app/Core/Router.php';
require_once __DIR__ . '/../app/Core/Controller.php';
require_once __DIR__ . '/../app/Core/DB.php';
require_once __DIR__ . '/../app/Core/Auth.php';

spl_autoload_register(function($class){
    $paths = [
        __DIR__ . '/../app/Controllers/' . $class . '.php',
        __DIR__ . '/../app/Models/' . $class . '.php',
    ];
    foreach($paths as $p){ if(file_exists($p)){ require_once $p; return; } }
});

Session::start();

$router = new Router();

// Rutas Auth
$router->get('/login', [ 'AuthController', 'showLogin' ]);
$router->post('/login', [ 'AuthController', 'login' ]);
$router->get('/logout', [ 'AuthController', 'logout' ]);

// Dashboard
$router->get('/', [ 'DashboardController', 'root' ]);
$router->get('/dashboard', [ 'DashboardController', 'index' ]);

// Usuarios
$router->get('/usuarios', [ 'UsuariosController', 'index' ]);
$router->post('/usuarios/store', [ 'UsuariosController', 'store' ]);
$router->post('/usuarios/update', [ 'UsuariosController', 'update' ]);
$router->post('/usuarios/delete', [ 'UsuariosController', 'delete' ]);

// Equipos
$router->get('/equipos', [ 'EquiposController', 'index' ]);
$router->post('/equipos/store', [ 'EquiposController', 'store' ]);
$router->post('/equipos/update', [ 'EquiposController', 'update' ]);
$router->post('/equipos/delete', [ 'EquiposController', 'delete' ]);

// Alertas
$router->get('/alertas', [ 'AlertasController', 'index' ]);
$router->get('/alertas/list', [ 'AlertasController', 'list' ]);
$router->post('/alertas/atender', [ 'AlertasController', 'atender' ]);
$router->get('/alertas/historial', [ 'AlertasController', 'historial' ]);
$router->post('/alertas/revertir', [ 'AlertasController', 'revertir' ]);

// API (ESP32)
$router->post('/api/alertas/registrar', [ 'ApiAlertasController', 'registrar' ]);

// Reportes
$router->get('/reportes', [ 'ReportesController', 'index' ]);
$router->get('/reportes/equipos', [ 'ReportesController', 'equipos' ]);
$router->get('/reportes/alertas', [ 'ReportesController', 'alertas' ]);

$router->dispatch();
