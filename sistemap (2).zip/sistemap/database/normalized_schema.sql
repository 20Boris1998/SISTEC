-- SISTEC - Esquema Normalizado (MySQL/MariaDB)
-- Crea una nueva base de datos normalizada sin afectar la actual

DROP DATABASE IF EXISTS sistemap_mvc;
CREATE DATABASE sistemap_mvc CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE sistemap_mvc;

-- =============================
-- Catálogos / Tablas maestras
-- =============================

-- Roles del sistema (clave técnica minúscula para lógica; nombre visible en MAYÚSCULAS)
CREATE TABLE roles (
  id TINYINT UNSIGNED NOT NULL AUTO_INCREMENT,
  clave VARCHAR(20) NOT NULL UNIQUE,     -- 'admin', 'tecnico'
  nombre VARCHAR(30) NOT NULL,           -- 'ADMINISTRADOR', 'TECNICO'
  PRIMARY KEY (id)
) ENGINE=InnoDB;

INSERT INTO roles (clave, nombre) VALUES
  ('admin','ADMINISTRADOR'),
  ('tecnico','TECNICO');

-- Ubicaciones (laboratorios)
CREATE TABLE ubicaciones (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  nombre VARCHAR(100) NOT NULL UNIQUE,   -- 'LABORATORIO 101'
  PRIMARY KEY (id)
) ENGINE=InnoDB;

-- (Eliminado) Estados de equipo: ya no se usa en el sistema

-- (Eliminado) Niveles de alerta: ya no se usa en el sistema

-- Estados de atención de la alerta
CREATE TABLE estados_alerta (
  id TINYINT UNSIGNED NOT NULL AUTO_INCREMENT,
  clave VARCHAR(20) NOT NULL UNIQUE,     -- 'NO_ATENDIDO', 'ATENDIDO'
  nombre VARCHAR(30) NOT NULL,
  PRIMARY KEY (id)
) ENGINE=InnoDB;

INSERT INTO estados_alerta (clave, nombre) VALUES
  ('NO_ATENDIDO','NO ATENDIDO'),
  ('ATENDIDO','ATENDIDO');

-- Tarjetas RFID (separadas para normalizar y permitir reutilización si aplica)
CREATE TABLE tarjetas (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  numero VARCHAR(100) NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uk_tarjeta_numero (numero)
) ENGINE=InnoDB;

-- =============================
-- Entidades principales
-- =============================

-- Usuarios
CREATE TABLE usuarios (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  usuario VARCHAR(50) NOT NULL,
  contrasena VARCHAR(255) NOT NULL,      -- Hash
  role_id TINYINT UNSIGNED NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uk_usuario (usuario),
  CONSTRAINT fk_usuarios_roles FOREIGN KEY (role_id)
    REFERENCES roles(id) ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB;

-- Equipos
CREATE TABLE equipos (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  nombre VARCHAR(100) NOT NULL,
  numero_serie VARCHAR(50) NOT NULL,
  ubicacion_id INT UNSIGNED NOT NULL,
  tarjeta_id INT UNSIGNED NOT NULL,
  fecha_registro DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_equipos_ubicacion (ubicacion_id),
  KEY idx_equipos_tarjeta (tarjeta_id),
  CONSTRAINT fk_equipos_ubicaciones FOREIGN KEY (ubicacion_id)
    REFERENCES ubicaciones(id) ON UPDATE CASCADE ON DELETE RESTRICT,
  CONSTRAINT fk_equipos_tarjetas FOREIGN KEY (tarjeta_id)
    REFERENCES tarjetas(id) ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB;

-- Alertas
CREATE TABLE alertas (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  mensaje TEXT NOT NULL,                 -- Texto de evento
  equipo_id INT UNSIGNED NULL,           -- Puede quedar NULL si se elimina el equipo
  ubicacion_id INT UNSIGNED NULL,        -- Ubicación reportada (opcional)
  estado_alerta_id TINYINT UNSIGNED NOT NULL,
  fecha DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_alertas_equipo (equipo_id),
  KEY idx_alertas_ubicacion (ubicacion_id),
  KEY idx_alertas_fecha (fecha),
  KEY idx_alertas_estado (estado_alerta_id),
  CONSTRAINT fk_alertas_equipos FOREIGN KEY (equipo_id)
    REFERENCES equipos(id) ON UPDATE CASCADE ON DELETE SET NULL,
  CONSTRAINT fk_alertas_ubicaciones FOREIGN KEY (ubicacion_id)
    REFERENCES ubicaciones(id) ON UPDATE CASCADE ON DELETE SET NULL,
  CONSTRAINT fk_alertas_estados FOREIGN KEY (estado_alerta_id)
    REFERENCES estados_alerta(id) ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB;

-- Historial de cambios de estado de alerta (trazabilidad)
CREATE TABLE alertas_historial (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  alerta_id INT UNSIGNED NOT NULL,
  estado_alerta_id TINYINT UNSIGNED NOT NULL,
  usuario VARCHAR(50) NULL,              -- Opcional: quién cambió
  fecha DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_hist_alerta (alerta_id),
  CONSTRAINT fk_hist_alerta FOREIGN KEY (alerta_id) REFERENCES alertas(id) ON DELETE CASCADE,
  CONSTRAINT fk_hist_estado FOREIGN KEY (estado_alerta_id) REFERENCES estados_alerta(id) ON DELETE RESTRICT
) ENGINE=InnoDB;

-- =============================
-- Datos semilla opcionales
-- =============================

-- Algunas ubicaciones comunes
INSERT INTO ubicaciones (nombre) VALUES
  ('LABORATORIO 101'),('LABORATORIO 102'),('LABORATORIO 201'),('LABORATORIO 202'),
  ('LABORATORIO 203'),('LABORATORIO 204'),('LABORATORIO 301'),('LABORATORIO 302'),
  ('LABORATORIO 303'),('LABORATORIO 304'),('LABORATORIO 401'),('LABORATORIO 402'),
  ('LABORATORIO 403'),('LABORATORIO 404'),('LABORATORIO 501'),('LABORATORIO 502'),
  ('LABORATORIO 503'),('LABORATORIO 504'),('LABORATORIO 601'),('LABORATORIO 602'),
  ('LABORATORIO 603'),('LABORATORIO 604'),('LABORATORIO 701'),('LABORATORIO 702'),
  ('LABORATORIO 703'),('LABORATORIO 704'),('LABORATORIO 801'),('LABORATORIO 802'),
  ('LABORATORIO 803'),('LABORATORIO 804');

-- =============================
-- Notas de migración
-- =============================
-- 1) Los roles ahora están en tabla 'roles'.
--    - Mapeo: 'admin' -> (roles.clave='admin'), 'tecnico' -> (roles.clave='tecnico').
-- 2) usuarios.rol (ENUM) se reemplaza por usuarios.role_id (FK a roles).
-- 3) equipos.estado (ENUM) se reemplaza por equipos.estado_id (FK a estados_equipo).
-- 4) equipos.numero_tarjeta_rfid ahora reside en 'tarjetas.numero'; equipos referencia con tarjeta_id (UNIQUE).
-- 5) alertas.numero_tarjeta_rfid se reemplaza por alertas.equipo_id y niveles_alerta.
-- 6) ubicacion se reemplaza por ubicacion_id apuntando a 'ubicaciones'.
-- 7) Todas las cadenas deben enviarse en MAYÚSCULAS desde la app para consistencia visual.

-- Para conectar la app a esta BD, ajusta config/database.php a 'name' => 'sistemap_mvc' y actualiza los modelos para usar FKs en lugar de ENUMs.
