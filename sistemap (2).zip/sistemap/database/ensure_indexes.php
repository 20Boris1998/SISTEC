<?php
// Asegura índices para alto rendimiento en la BD actual (sistemap_mvc)
// Uso: abrir en navegador: http://<host>/sistemap/database/ensure_indexes.php
// o CLI: php database/ensure_indexes.php

require_once __DIR__ . '/../app/Core/DB.php';

function idx_exists($conn, $table, $index) {
    $stmt = $conn->prepare("SHOW INDEX FROM `$table` WHERE Key_name = ?");
    $stmt->bind_param('s', $index);
    $stmt->execute();
    $res = $stmt->get_result();
    return ($res && $res->num_rows > 0);
}

$conn = DB::conn();
$conn->set_charset('utf8mb4');
$created = [];
$skipped = [];
$errors = [];

$targets = [
    ['table' => 'equipos', 'sql' => 'CREATE INDEX idx_equipos_ubicacion ON equipos (ubicacion_id)', 'name' => 'idx_equipos_ubicacion'],
    ['table' => 'equipos', 'sql' => 'CREATE INDEX idx_equipos_estado ON equipos (estado_id)', 'name' => 'idx_equipos_estado'],
    ['table' => 'alertas', 'sql' => 'CREATE INDEX idx_alertas_nivel ON alertas (nivel_id)', 'name' => 'idx_alertas_nivel'],
    ['table' => 'alertas', 'sql' => 'CREATE INDEX idx_alertas_fecha ON alertas (fecha)', 'name' => 'idx_alertas_fecha'],
];

foreach ($targets as $t) {
    $table = $t['table'];
    $name  = $t['name'];
    $sql   = $t['sql'];
    try {
        $exists = idx_exists($conn, $table, $name);
        if ($exists) { $skipped[] = "$table.$name"; continue; }
        if (!$conn->query($sql)) { $errors[] = "$table.$name: " . $conn->error; }
        else { $created[] = "$table.$name"; }
    } catch (Throwable $e) {
        $errors[] = "$table.$name: " . $e->getMessage();
    }
}

header('Content-Type: application/json');
echo json_encode([
    'success' => empty($errors),
    'created' => $created,
    'skipped' => $skipped,
    'errors'  => $errors,
], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
