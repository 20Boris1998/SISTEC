<?php
require_once __DIR__ . '/../app/Core/DB.php';
header('Content-Type: application/json');
$conn = DB::conn();
$conn->set_charset('utf8mb4');
$out = ['dropped'=>[], 'added'=>[], 'updated'=>[], 'skipped'=>[], 'errors'=>[]];

function table_exists($conn,$t){ $res=$conn->query("SHOW TABLES LIKE '".$conn->real_escape_string($t)."'"); return ($res && $res->num_rows>0); }
function col_exists($conn,$t,$c){ $sql="SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='".$conn->real_escape_string($t)."' AND COLUMN_NAME='".$conn->real_escape_string($c)."'"; $r=$conn->query($sql); return ($r&&$r->num_rows>0); }
function fk_exists($conn,$t,$fk){ $stmt=$conn->prepare("SELECT 1 FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE CONSTRAINT_SCHEMA=DATABASE() AND TABLE_NAME=? AND CONSTRAINT_NAME=? AND CONSTRAINT_TYPE='FOREIGN KEY'"); $stmt->bind_param('ss',$t,$fk); $stmt->execute(); $r=$stmt->get_result(); return ($r&&$r->num_rows>0); }
function idx_exists($conn,$t,$idx){ $stmt=$conn->prepare("SHOW INDEX FROM `$t` WHERE Key_name=?"); $stmt->bind_param('s',$idx); $stmt->execute(); $r=$stmt->get_result(); return ($r&&$r->num_rows>0); }

// 1) Normalized path: equipos.estado_id -> drop FK and column, add equipos.numero_serie
try {
  if (table_exists($conn,'equipos')) {
    // Drop FK if present
    if (fk_exists($conn,'equipos','fk_equipos_estados')) {
      if ($conn->query("ALTER TABLE equipos DROP FOREIGN KEY fk_equipos_estados")) $out['dropped'][]='fk_equipos_estados'; else $out['errors'][]=$conn->error;
    } else { $out['skipped'][]='fk_equipos_estados'; }
    // Drop index if present
    if (idx_exists($conn,'equipos','idx_equipos_estado')) {
      if ($conn->query("DROP INDEX idx_equipos_estado ON equipos")) $out['dropped'][]='idx_equipos_estado'; else $out['errors'][]=$conn->error;
    } else { $out['skipped'][]='idx_equipos_estado'; }
    // Drop column estado_id if present
    if (col_exists($conn,'equipos','estado_id')) {
      if ($conn->query("ALTER TABLE equipos DROP COLUMN estado_id")) $out['dropped'][]='equipos.estado_id'; else $out['errors'][]=$conn->error;
    } else { $out['skipped'][]='equipos.estado_id'; }
    // Add numero_serie if missing
    if (!col_exists($conn,'equipos','numero_serie')) {
      if ($conn->query("ALTER TABLE equipos ADD COLUMN numero_serie VARCHAR(50) NOT NULL AFTER nombre")) $out['added'][]='equipos.numero_serie'; else $out['errors'][]=$conn->error;
    } else { $out['skipped'][]='equipos.numero_serie'; }
  }
} catch(Throwable $e){ $out['errors'][]=$e->getMessage(); }

// 2) Legacy path: equipos.estado -> drop column, add numero_serie
try {
  if (table_exists($conn,'equipos')) {
    if (col_exists($conn,'equipos','estado')) {
      if ($conn->query("ALTER TABLE equipos DROP COLUMN estado")) $out['dropped'][]='equipos.estado'; else $out['errors'][]=$conn->error;
    } else { $out['skipped'][]='equipos.estado'; }
    if (!col_exists($conn,'equipos','numero_serie')) {
      if ($conn->query("ALTER TABLE equipos ADD COLUMN numero_serie VARCHAR(50) NOT NULL AFTER nombre")) $out['added'][]='equipos.numero_serie.legacy'; else $out['errors'][]=$conn->error;
    } else { $out['skipped'][]='equipos.numero_serie.legacy'; }
  }
} catch(Throwable $e){ $out['errors'][]=$e->getMessage(); }

// 3) Drop estados_equipo table if exists
try {
  if (table_exists($conn,'estados_equipo')) {
    if ($conn->query("DROP TABLE estados_equipo")) $out['dropped'][]='table.estados_equipo'; else $out['errors'][]=$conn->error;
  } else { $out['skipped'][]='table.estados_equipo'; }
} catch(Throwable $e){ $out['errors'][]=$e->getMessage(); }

$out['success'] = empty($out['errors']);
echo json_encode($out, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE);
