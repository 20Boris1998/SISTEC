<?php
require_once __DIR__ . '/../app/Core/DB.php';
header('Content-Type: application/json');
$conn = DB::conn();
$conn->set_charset('utf8mb4');
$uid = null; $id = null;
// Try normalized
$sql = "SELECT e.id, t.numero AS numero_tarjeta_rfid FROM equipos e JOIN tarjetas t ON t.id=e.tarjeta_id ORDER BY e.id DESC LIMIT 1";
$res = $conn->query($sql);
if ($res && ($row = $res->fetch_assoc())) { $id = (int)$row['id']; $uid = $row['numero_tarjeta_rfid']; }
else {
  // legacy fallback
  $res = $conn->query("SELECT id, numero_tarjeta_rfid FROM equipos ORDER BY id DESC LIMIT 1");
  if ($res && ($row = $res->fetch_assoc())) { $id = (int)$row['id']; $uid = $row['numero_tarjeta_rfid']; }
}
if (!$uid) { echo json_encode(['success'=>false,'error'=>'No hay equipos registrados']); exit; }
echo json_encode(['success'=>true,'equipo_id'=>$id,'numero_tarjeta_rfid'=>$uid], JSON_UNESCAPED_UNICODE);
