<?php
require_once __DIR__ . '/../app/Core/DB.php';
header('Content-Type: application/json');
$conn = DB::conn();
$out = ['dropped'=>[], 'skipped'=>[], 'errors'=>[]];

function col_exists($conn,$table,$col){
  $stmt=$conn->prepare("SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=? AND COLUMN_NAME=? LIMIT 1");
  $stmt->bind_param('ss',$table,$col); $stmt->execute(); $r=$stmt->get_result(); return ($r && $r->num_rows>0);
}
function idx_exists($conn,$table,$idx){
  $stmt=$conn->prepare("SHOW INDEX FROM `$table` WHERE Key_name=?");
  $stmt->bind_param('s',$idx); $stmt->execute(); $r=$stmt->get_result(); return ($r && $r->num_rows>0);
}
function fk_exists($conn,$table,$fk){
  $stmt=$conn->prepare("SELECT 1 FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE CONSTRAINT_SCHEMA=DATABASE() AND TABLE_NAME=? AND CONSTRAINT_NAME=? AND CONSTRAINT_TYPE='FOREIGN KEY'");
  $stmt->bind_param('ss',$table,$fk); $stmt->execute(); $r=$stmt->get_result(); return ($r && $r->num_rows>0);
}
function table_exists($conn,$table){ $res=$conn->query("SHOW TABLES LIKE '".$conn->real_escape_string($table)."'"); return ($res&&$res->num_rows>0); }

// Drop FK on alertas to niveles_alerta if exists
try {
  if (fk_exists($conn,'alertas','fk_alertas_niveles')){
    if ($conn->query("ALTER TABLE alertas DROP FOREIGN KEY fk_alertas_niveles")) $out['dropped'][]='fk_alertas_niveles'; else $out['errors'][]=$conn->error;
  } else { $out['skipped'][]='fk_alertas_niveles'; }
} catch(Throwable $e){ $out['errors'][]=$e->getMessage(); }

// Drop index on nivel if exists
try {
  if (idx_exists($conn,'alertas','idx_alertas_nivel')){
    if ($conn->query("DROP INDEX idx_alertas_nivel ON alertas")) $out['dropped'][]='idx_alertas_nivel'; else $out['errors'][]=$conn->error;
  } else { $out['skipped'][]='idx_alertas_nivel'; }
} catch(Throwable $e){ $out['errors'][]=$e->getMessage(); }

// Drop column nivel_id if exists
try {
  if (col_exists($conn,'alertas','nivel_id')){
    if ($conn->query("ALTER TABLE alertas DROP COLUMN nivel_id")) $out['dropped'][]='alertas.nivel_id'; else $out['errors'][]=$conn->error;
  } else { $out['skipped'][]='alertas.nivel_id'; }
} catch(Throwable $e){ $out['errors'][]=$e->getMessage(); }

// Drop niveles_alerta table if exists
try {
  if (table_exists($conn,'niveles_alerta')){
    if ($conn->query("DROP TABLE niveles_alerta")) $out['dropped'][]='table.niveles_alerta'; else $out['errors'][]=$conn->error;
  } else { $out['skipped'][]='table.niveles_alerta'; }
} catch(Throwable $e){ $out['errors'][]=$e->getMessage(); }

$out['success']=empty($out['errors']);
echo json_encode($out, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE);
