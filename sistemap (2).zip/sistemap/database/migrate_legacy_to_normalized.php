<?php
// Migración de datos: basededatossistec -> sistemap_mvc
// Ejecutar desde CLI: php -f c:/xampp/htdocs/sistemap/database/migrate_legacy_to_normalized.php

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

function connectDb($host, $user, $pass, $name = null) {
    $conn = new mysqli($host, $user, $pass, $name);
    $conn->set_charset('utf8mb4');
    return $conn;
}

$host = 'localhost';
$user = 'root';
$pass = '';
$oldDb = 'basededatossistec';
$newDb = 'sistemap_mvc';

try {
    echo "Conectando a BD origen: {$oldDb}\n";
    $old = connectDb($host, $user, $pass, $oldDb);

    echo "Conectando/creando BD destino: {$newDb}\n";
    $bootstrap = connectDb($host, $user, $pass);
    $bootstrap->query("CREATE DATABASE IF NOT EXISTS `{$newDb}` CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci");
    $bootstrap->close();
    $new = connectDb($host, $user, $pass, $newDb);

    // Asegurar esquema normalizado (si no existe, intentar cargar script)
    $hasRoles = $new->query("SHOW TABLES LIKE 'roles'")->num_rows > 0;
    if (!$hasRoles) {
        $schema = __DIR__ . '/normalized_schema.sql';
        if (!file_exists($schema)) throw new Exception("No se encuentra normalized_schema.sql");
        echo "Cargando esquema normalizado...\n";
        $sql = file_get_contents($schema);
        $new->multi_query($sql);
        while ($new->more_results() && $new->next_result()) { /* avanzar */ }
    }

    // Asegurar rol INVITADO si existiera en legacy
    $hasInv = false;
    $resInvLegacy = $old->query("SELECT COUNT(*) c FROM usuarios WHERE rol='invitado'");
    if ($resInvLegacy && intval($resInvLegacy->fetch_assoc()['c'] ?? 0) > 0) {
        $chkInv = $new->prepare("SELECT id FROM roles WHERE clave='invitado'");
        $chkInv->execute();
        $r = $chkInv->get_result();
        if ($r->num_rows === 0) {
            $insInv = $new->prepare("INSERT INTO roles (clave, nombre) VALUES ('invitado','INVITADO')");
            $insInv->execute();
            echo "Rol INVITADO creado en destino.\n";
        }
        $hasInv = true;
    }

    // Mapas auxiliares
    $roleMap = [];
    $rres = $new->query("SELECT id, clave FROM roles");
    while ($row = $rres->fetch_assoc()) { $roleMap[$row['clave']] = intval($row['id']); }

    // Usuarios
    echo "Migrando usuarios...\n";
    $uSel = $old->query("SELECT id, usuario, contrasena, rol FROM usuarios ORDER BY id ASC");
    $chkUser = $new->prepare("SELECT id FROM usuarios WHERE usuario = ?");
    $insUser = $new->prepare("INSERT INTO usuarios (usuario, contrasena, role_id) VALUES (?, ?, ?)");
    while ($u = $uSel->fetch_assoc()) {
        $usuario = strtoupper(trim($u['usuario'] ?? ''));
        $hash = $u['contrasena'];
        $rolClave = $u['rol'];
        if (!isset($roleMap[$rolClave])) {
            // Si hay un rol desconocido, intenta crearlo en roles
            $nombre = strtoupper($rolClave);
            $new->query("INSERT IGNORE INTO roles (clave, nombre) VALUES ('{$rolClave}','{$nombre}')");
            $ridRes = $new->query("SELECT id FROM roles WHERE clave='{".$rolClave."}' LIMIT 1");
        }
        $roleId = $roleMap[$rolClave] ?? intval(($new->query("SELECT id FROM roles WHERE clave='".$new->real_escape_string($rolClave)."' LIMIT 1")->fetch_assoc()['id'] ?? 0));
        if (!$roleId) { $roleId = $roleMap['tecnico'] ?? array_values($roleMap)[0]; }

        $chkUser->bind_param('s', $usuario);
        $chkUser->execute();
        $exists = $chkUser->get_result()->num_rows > 0;
        if (!$exists) {
            $insUser->bind_param('ssi', $usuario, $hash, $roleId);
            $insUser->execute();
        }
    }

    // Tarjetas (desde equipos legacy)
    echo "Migrando tarjetas...\n";
    $rfids = [];
    $eSelRF = $old->query("SELECT DISTINCT numero_tarjeta_rfid FROM equipos WHERE numero_tarjeta_rfid IS NOT NULL AND numero_tarjeta_rfid <> ''");
    while ($r = $eSelRF->fetch_assoc()) { $rfids[] = strtoupper(trim($r['numero_tarjeta_rfid'])); }
    $insTar = $new->prepare("INSERT IGNORE INTO tarjetas (numero) VALUES (?)");
    foreach ($rfids as $rf) { $insTar->bind_param('s', $rf); $insTar->execute(); }

    // Ubicaciones (desde equipos y alertas legacy)
    echo "Migrando ubicaciones...\n";
    $ubicaciones = [];
    $u1 = $old->query("SELECT DISTINCT ubicacion FROM equipos WHERE ubicacion IS NOT NULL AND ubicacion <> ''");
    while ($r = $u1->fetch_assoc()) { $ubicaciones[] = strtoupper(trim($r['ubicacion'])); }
    $u2 = $old->query("SELECT DISTINCT ubicacion FROM alertas WHERE ubicacion IS NOT NULL AND ubicacion <> ''");
    while ($r = $u2->fetch_assoc()) { $ubicaciones[] = strtoupper(trim($r['ubicacion'])); }
    $ubicaciones = array_values(array_unique($ubicaciones));
    $insUb = $new->prepare("INSERT IGNORE INTO ubicaciones (nombre) VALUES (?)");
    foreach ($ubicaciones as $ub) { $insUb->bind_param('s', $ub); $insUb->execute(); }

    // Estados de equipo ya sembrados en schema (AUTORIZADO / NO AUTORIZADO)

    // Equipos
    echo "Migrando equipos...\n";
    $eSel = $old->query("SELECT id, nombre, ubicacion, estado, fecha_registro, numero_tarjeta_rfid FROM equipos ORDER BY id ASC");
    $getTar = $new->prepare("SELECT id FROM tarjetas WHERE numero = ?");
    $getUb = $new->prepare("SELECT id FROM ubicaciones WHERE nombre = ?");
    $getEs = $new->prepare("SELECT id FROM estados_equipo WHERE clave = ?");
    $insEq = $new->prepare("INSERT INTO equipos (nombre, ubicacion_id, estado_id, fecha_registro, tarjeta_id) VALUES (?, ?, ?, ?, ?)");
    while ($e = $eSel->fetch_assoc()) {
        $nombre = strtoupper(trim($e['nombre'] ?? ''));
        $ubic = strtoupper(trim($e['ubicacion'] ?? ''));
        $estado = strtoupper(trim($e['estado'] ?? ''));
        $fecha = $e['fecha_registro'] ?? date('Y-m-d H:i:s');
        $rf = strtoupper(trim($e['numero_tarjeta_rfid'] ?? ''));

        // ubicacion_id
        $getUb->bind_param('s', $ubic);
        $getUb->execute();
        $uid = $getUb->get_result()->fetch_assoc()['id'] ?? null;
        if (!$uid && $ubic !== '') {
            $insUb->bind_param('s', $ubic);
            $insUb->execute();
            $uid = $new->insert_id;
        }
        // estado_id
        $estadoClave = $estado;
        if ($estadoClave === 'NO AUTORIZADO' || $estadoClave === 'NO AUTORIZADO') { $estadoClave = 'NO AUTORIZADO'; }
        $getEs->bind_param('s', $estadoClave);
        $getEs->execute();
        $eid = $getEs->get_result()->fetch_assoc()['id'] ?? null;
        if (!$eid) continue; // saltar si no hay estado válido
        // tarjeta
        $getTar->bind_param('s', $rf);
        $getTar->execute();
        $tid = $getTar->get_result()->fetch_assoc()['id'] ?? null;
        if (!$tid && $rf !== '') { $insTar->bind_param('s', $rf); $insTar->execute(); $tid = $new->insert_id; }

        $insEq->bind_param('sissi', $nombre, $uid, $eid, $fecha, $tid);
        $insEq->execute();
    }

    // Niveles de alerta ya sembrados (PELIGRO/CUIDADO)

    // Alertas
    echo "Migrando alertas...\n";
    $aSel = $old->query("SELECT id, mensaje, ubicacion, nivel, fecha, numero_tarjeta_rfid FROM alertas ORDER BY id ASC");
    $getEqByTar = $new->prepare("SELECT e.id FROM equipos e JOIN tarjetas t ON t.id = e.tarjeta_id WHERE t.numero = ? LIMIT 1");
    $getUb2 = $new->prepare("SELECT id FROM ubicaciones WHERE nombre = ?");
    $getNivel = $new->prepare("SELECT id FROM niveles_alerta WHERE clave = ?");
    $insAl = $new->prepare("INSERT INTO alertas (mensaje, equipo_id, ubicacion_id, nivel_id, fecha) VALUES (?, ?, ?, ?, ?)");
    while ($a = $aSel->fetch_assoc()) {
        $msg = $a['mensaje'];
        $ubic = strtoupper(trim($a['ubicacion'] ?? ''));
        $nivelClave = strtoupper(trim($a['nivel'] ?? ''));
        if ($nivelClave === 'PELIGRO' || $nivelClave === 'CUIDADO') { /* ok */ }
        $fecha = $a['fecha'] ?? date('Y-m-d H:i:s');
        $rf = strtoupper(trim($a['numero_tarjeta_rfid'] ?? ''));
        // equipo
        $eqId = null;
        if ($rf !== '') {
            $getEqByTar->bind_param('s', $rf);
            $getEqByTar->execute();
            $eqId = $getEqByTar->get_result()->fetch_assoc()['id'] ?? null;
        }
        // ubicacion
        $uid = null;
        if ($ubic !== '') {
            $getUb2->bind_param('s', $ubic);
            $getUb2->execute();
            $uid = $getUb2->get_result()->fetch_assoc()['id'] ?? null;
            if (!$uid) { $insUb->bind_param('s', $ubic); $insUb->execute(); $uid = $new->insert_id; }
        }
        // nivel
        $getNivel->bind_param('s', $nivelClave);
        $getNivel->execute();
        $nid = $getNivel->get_result()->fetch_assoc()['id'] ?? null;
        if (!$nid) continue;

        $insAl->bind_param('siiis', $msg, $eqId, $uid, $nid, $fecha);
        $insAl->execute();
    }

    echo "Migración completada.\n";
} catch (Throwable $e) {
    http_response_code(500);
    echo "Error en migración: ".$e->getMessage()."\n";
    exit(1);
}
