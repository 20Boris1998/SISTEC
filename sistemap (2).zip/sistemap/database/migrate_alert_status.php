<?php
require_once __DIR__ . '/../app/Core/DB.php';

$conn = DB::conn();
$conn->set_charset('utf8mb4');
header('Content-Type: application/json');

$out = ['created'=>[], 'updated'=>[], 'skipped'=>[], 'errors'=>[]];

function table_exists($conn, $table){
  $res = $conn->query("SHOW TABLES LIKE '".$conn->real_escape_string($table)."'");
  return $res && $res->num_rows > 0;
}
function column_exists($conn, $table, $col){
  $stmt = $conn->prepare("SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ? LIMIT 1");
  $stmt->bind_param('ss', $table, $col);
  $stmt->execute();
  $r = $stmt->get_result();
  return $r && $r->num_rows > 0;
}
function idx_exists($conn, $table, $index){
  $stmt = $conn->prepare("SHOW INDEX FROM `$table` WHERE Key_name = ?");
  $stmt->bind_param('s', $index);
  $stmt->execute();
  $r = $stmt->get_result();
  return $r && $r->num_rows > 0;
}
function fk_exists($conn, $table, $fk){
  $stmt = $conn->prepare("SELECT 1 FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE CONSTRAINT_SCHEMA = DATABASE() AND TABLE_NAME = ? AND CONSTRAINT_NAME = ? AND CONSTRAINT_TYPE='FOREIGN KEY'");
  $stmt->bind_param('ss', $table, $fk);
  $stmt->execute();
  $r = $stmt->get_result();
  return $r && $r->num_rows > 0;
}

// 1) estados_alerta
try {
  if (!table_exists($conn, 'estados_alerta')) {
    $sql = "CREATE TABLE estados_alerta (\n      id TINYINT UNSIGNED NOT NULL AUTO_INCREMENT,\n      clave VARCHAR(20) NOT NULL UNIQUE,\n      nombre VARCHAR(30) NOT NULL,\n      PRIMARY KEY (id)\n    ) ENGINE=InnoDB";
    if ($conn->query($sql)) { $out['created'][] = 'table.estados_alerta'; } else { $out['errors'][] = $conn->error; }
  } else { $out['skipped'][] = 'table.estados_alerta'; }
  // seed
  $pairs = [ ['NO_ATENDIDO','NO ATENDIDO'], ['ATENDIDO','ATENDIDO'] ];
  foreach ($pairs as $p) {
    [$clave, $nombre] = $p;
    $stmt = $conn->prepare("SELECT id FROM estados_alerta WHERE clave = ?");
    $stmt->bind_param('s', $clave);
    $stmt->execute();
    $id = $stmt->get_result()->fetch_assoc()['id'] ?? null;
    if (!$id) {
      $ins = $conn->prepare("INSERT INTO estados_alerta (clave, nombre) VALUES (?, ?)");
      $ins->bind_param('ss', $clave, $nombre);
      if ($ins->execute()) { $out['created'][] = 'seed.estados_alerta.'.$clave; } else { $out['errors'][] = $conn->error; }
    } else { $out['skipped'][] = 'seed.estados_alerta.'.$clave; }
  }
} catch (Throwable $e) { $out['errors'][] = $e->getMessage(); }

// 2) alertas.estado_alerta_id column
try {
  if (!column_exists($conn, 'alertas', 'estado_alerta_id')) {
    if (!$conn->query("ALTER TABLE alertas ADD COLUMN estado_alerta_id TINYINT UNSIGNED NULL AFTER nivel_id")) { $out['errors'][] = $conn->error; }
    else { $out['updated'][] = 'alertas.add.estado_alerta_id'; }
  } else { $out['skipped'][] = 'alertas.add.estado_alerta_id'; }
  // backfill NO_ATENDIDO
  $noId = null;
  $res = $conn->query("SELECT id FROM estados_alerta WHERE clave='NO_ATENDIDO' LIMIT 1");
  if ($res && ($row = $res->fetch_assoc())) { $noId = (int)$row['id']; }
  if ($noId) {
    if (!$conn->query("UPDATE alertas SET estado_alerta_id = IFNULL(estado_alerta_id, $noId)")) { $out['errors'][] = $conn->error; }
    else { $out['updated'][] = 'alertas.backfill.estado_alerta_id'; }
  }
  // index
  if (!idx_exists($conn, 'alertas', 'idx_alertas_estado')) {
    if ($conn->query("CREATE INDEX idx_alertas_estado ON alertas (estado_alerta_id)")) { $out['created'][] = 'index.idx_alertas_estado'; } else { $out['errors'][] = $conn->error; }
  } else { $out['skipped'][] = 'index.idx_alertas_estado'; }
  // FK
  if (!fk_exists($conn, 'alertas', 'fk_alertas_estados')) {
    if (!$conn->query("ALTER TABLE alertas ADD CONSTRAINT fk_alertas_estados FOREIGN KEY (estado_alerta_id) REFERENCES estados_alerta(id) ON UPDATE CASCADE ON DELETE RESTRICT")) { $out['errors'][] = $conn->error; }
    else { $out['created'][] = 'fk.fk_alertas_estados'; }
  } else { $out['skipped'][] = 'fk.fk_alertas_estados'; }
} catch (Throwable $e) { $out['errors'][] = $e->getMessage(); }

// 3) alertas_historial
try {
  if (!table_exists($conn, 'alertas_historial')) {
    $sql = "CREATE TABLE alertas_historial (\n      id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,\n      alerta_id INT UNSIGNED NOT NULL,\n      estado_alerta_id TINYINT UNSIGNED NOT NULL,\n      usuario VARCHAR(50) NULL,\n      fecha DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,\n      PRIMARY KEY (id),\n      KEY idx_hist_alerta (alerta_id),\n      CONSTRAINT fk_hist_alerta FOREIGN KEY (alerta_id) REFERENCES alertas(id) ON DELETE CASCADE,\n      CONSTRAINT fk_hist_estado FOREIGN KEY (estado_alerta_id) REFERENCES estados_alerta(id) ON DELETE RESTRICT\n    ) ENGINE=InnoDB";
    if ($conn->query($sql)) { $out['created'][] = 'table.alertas_historial'; } else { $out['errors'][] = $conn->error; }
  } else { $out['skipped'][] = 'table.alertas_historial'; }
  // backfill historial: una entrada por alerta con estado actual
  $res = $conn->query("SELECT a.id, a.estado_alerta_id FROM alertas a LEFT JOIN (SELECT alerta_id, COUNT(*) c FROM alertas_historial GROUP BY alerta_id) h ON h.alerta_id=a.id WHERE h.c IS NULL");
  if ($res) {
    while ($row = $res->fetch_assoc()) {
      $aid = (int)$row['id']; $eid = (int)$row['estado_alerta_id'];
      if ($eid > 0) {
        $ins = $conn->prepare('INSERT INTO alertas_historial (alerta_id, estado_alerta_id, usuario) VALUES (?, ?, NULL)');
        $ins->bind_param('ii', $aid, $eid);
        if ($ins->execute()) { $out['created'][] = 'hist.alerta.'.$aid; } else { $out['errors'][] = $conn->error; }
      }
    }
  }
} catch (Throwable $e) { $out['errors'][] = $e->getMessage(); }

$out['success'] = empty($out['errors']);
echo json_encode($out, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
