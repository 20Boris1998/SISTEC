<?php
return [
    'base_path' => '/sistemap/public',
    'views_path' => __DIR__ . '/../app/Views',
    'api_key' => 'API12345',
];
