<?php
class Session {
    public static function start() {
        if (session_status() !== PHP_SESSION_ACTIVE) {
            $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
            session_set_cookie_params([
                'httponly' => true,
                'secure' => $secure,
                'samesite' => 'Lax',
            ]);
            session_start();
        }
    }
    public static function get($k, $d=null){return $_SESSION[$k]??$d;}
    public static function set($k,$v){$_SESSION[$k]=$v;}
    public static function regenerate(){ if (session_status()===PHP_SESSION_ACTIVE) session_regenerate_id(true); }
    public static function destroy(){
        if (session_status()===PHP_SESSION_ACTIVE) {
            $_SESSION = [];
            if (ini_get('session.use_cookies')) {
                $params = session_get_cookie_params();
                setcookie(session_name(), '', time()-42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
            }
            session_destroy();
        }
    }
    public static function csrfToken(){
        if (!isset($_SESSION['_csrf'])) { $_SESSION['_csrf'] = bin2hex(random_bytes(32)); }
        return $_SESSION['_csrf'];
    }
    public static function validateCsrf($token){
        $t = $_SESSION['_csrf'] ?? '';
        return is_string($token) && is_string($t) && hash_equals($t, $token);
    }
}
