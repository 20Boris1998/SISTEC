<?php
class DB {
    private static $conn;
    public static function conn() {
        if (!self::$conn) {
            $cfg = require __DIR__ . '/../../config/database.php';
            try {
                self::$conn = new mysqli($cfg['host'], $cfg['user'], $cfg['pass'], $cfg['name']);
            } catch (\mysqli_sql_exception $e) {
                $msg = $e->getMessage();
                $code = (int)$e->getCode();
                $unknownDb = ($code === 1049) || (stripos($msg, 'unknown database') !== false);
                if (!$unknownDb) { throw $e; }
                // Bootstrap sin BD
                $bootstrap = new mysqli($cfg['host'], $cfg['user'], $cfg['pass']);
                if ($bootstrap->connect_error) {
                    http_response_code(500);
                    exit('Error de conexión.');
                }
                $schemaPath = __DIR__ . '/../../database/normalized_schema.sql';
                if (file_exists($schemaPath)) {
                    $sql = file_get_contents($schemaPath);
                    if ($sql !== false) {
                        if (!$bootstrap->multi_query($sql)) {
                            http_response_code(500);
                            exit('Error al inicializar la base de datos.');
                        }
                        while ($bootstrap->more_results() && $bootstrap->next_result()) { /* avanzar */ }
                    }
                } else {
                    $bootstrap->query("CREATE DATABASE IF NOT EXISTS `" . $cfg['name'] . "` CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci");
                    $bootstrap->query("USE `" . $cfg['name'] . "`");
                }
                $bootstrap->close();
                // Reintentar conexión
                self::$conn = new mysqli($cfg['host'], $cfg['user'], $cfg['pass'], $cfg['name']);
                // Semilla ADMIN si no hay usuarios
                if (!self::$conn->connect_error) {
                    if ($r = self::$conn->query("SHOW TABLES LIKE 'usuarios'")) {
                        if ($r->num_rows > 0) {
                            $c = self::$conn->query("SELECT COUNT(*) AS c FROM usuarios");
                            $row = $c ? $c->fetch_assoc() : ['c'=>0];
                            if (intval($row['c'] ?? 0) === 0) {
                                $ridRes = self::$conn->query("SELECT id FROM roles WHERE clave='admin' LIMIT 1");
                                $rid = $ridRes && $ridRes->num_rows ? intval($ridRes->fetch_assoc()['id']) : null;
                                if ($rid) {
                                    $usuario = 'ADMIN';
                                    $hash = password_hash('ADMIN12345', PASSWORD_DEFAULT);
                                    $stmt = self::$conn->prepare("INSERT INTO usuarios (usuario, contrasena, role_id) VALUES (?, ?, ?)");
                                    if ($stmt) { $stmt->bind_param('ssi', $usuario, $hash, $rid); $stmt->execute(); }
                                }
                            }
                        }
                    }
                }
            }
            if (self::$conn->connect_error) { http_response_code(500); exit('Error de conexión.'); }
        }
        return self::$conn;
    }
}
