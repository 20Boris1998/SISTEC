<?php
class Controller {
    protected function render($view, $data=[], $layout=true) {
        $app = require __DIR__ . '/../../config/app.php';
        extract($data);
        $views = $app['views_path'];
        if ($layout) {
            require $views . '/layout/header.php';
            require $views . '/' . $view . '.php';
            require $views . '/layout/footer.php';
        } else {
            require $views . '/' . $view . '.php';
        }
    }
    protected function redirect($path){ header('Location: ' . $path); exit; }
}
