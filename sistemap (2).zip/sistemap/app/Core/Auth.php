<?php
class Auth {
    public static function check(){return !!Session::get('usuario');}
    public static function requireLogin(){ if(!self::check()){ header('Location: /sistemap/public/login'); exit; } }
    public static function login($usuario,$rol){ Session::set('usuario',$usuario); Session::set('rol',$rol); Session::regenerate(); }
    public static function logout(){ Session::destroy(); header('Location: /sistemap/public/login'); exit; }
    public static function role(){return Session::get('rol');}
}
