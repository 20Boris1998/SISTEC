<?php
class Router {
    private $routes = [];
    public function get($path, $handler){ $this->routes['GET'][$path]=$handler; }
    public function post($path, $handler){ $this->routes['POST'][$path]=$handler; }
    public function dispatch(){
        $method = $_SERVER['REQUEST_METHOD'];
        $uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
        $base = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/');
        $path = '/' . ltrim(substr($uri, strlen($base)), '/');
        if ($path==='') $path='/';
        $handler = $this->routes[$method][$path] ?? null;
        if(!$handler){ http_response_code(404); echo '404'; return; }
        [$controller,$action] = $handler;
        $c = new $controller();
        $c->$action();
    }
}
