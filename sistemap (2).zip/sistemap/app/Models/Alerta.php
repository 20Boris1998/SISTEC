<?php
class Alerta {
    private static function isNormalized() {
        $conn = DB::conn();
        $res = $conn->query("SHOW TABLES LIKE 'roles'");
        return $res && $res->num_rows > 0;
    }
    public static function all() {
        $conn = DB::conn();
        if (self::isNormalized()) {
            $sql = "SELECT a.id, a.mensaje, a.fecha,
                           u.nombre AS ubicacion,
                           ea.nombre AS estado_alerta,
                           t.numero AS numero_tarjeta_rfid,
                           e.numero_serie AS numero_serie
                    FROM alertas a
                    LEFT JOIN equipos e ON e.id = a.equipo_id
                    LEFT JOIN tarjetas t ON t.id = e.tarjeta_id
                    LEFT JOIN ubicaciones u ON u.id = a.ubicacion_id
                    JOIN estados_alerta ea ON ea.id = a.estado_alerta_id
                    ORDER BY a.fecha DESC";
        } else {
            $sql = "SELECT * FROM alertas ORDER BY fecha DESC";
        }
        $res = $conn->query($sql);
        $out = [];
        while ($row = $res->fetch_assoc()) { $out[] = $row; }
        return $out;
    }
    public static function filtered($dia, $mes, $anio, $estadoClave = null) {
        $conn = DB::conn();
        $out = [];
        if (self::isNormalized()) {
            $base = "SELECT a.id, a.mensaje, a.fecha,
                            u.nombre AS ubicacion,
                            ea.nombre AS estado_alerta,
                            t.numero AS numero_tarjeta_rfid,
                            e.numero_serie AS numero_serie
                     FROM alertas a
                     LEFT JOIN equipos e ON e.id = a.equipo_id
                     LEFT JOIN tarjetas t ON t.id = e.tarjeta_id
                     LEFT JOIN ubicaciones u ON u.id = a.ubicacion_id
                     JOIN estados_alerta ea ON ea.id = a.estado_alerta_id
                     WHERE 1=1";
            $conds = [];
            $types = '';
            $params = [];
            if (!empty($dia))  { $conds[] = " AND DAY(a.fecha) = ?"; $types .= 'i'; $params[] = (int)$dia; }
            if (!empty($mes))  { $conds[] = " AND MONTH(a.fecha) = ?"; $types .= 'i'; $params[] = (int)$mes; }
            if (!empty($anio)) { $conds[] = " AND YEAR(a.fecha) = ?"; $types .= 'i'; $params[] = (int)$anio; }
            if (!empty($estadoClave)) {
                $estadoClave = strtoupper($estadoClave);
                if (in_array($estadoClave, ['NO_ATENDIDO','ATENDIDO'], true)) {
                    $conds[] = " AND ea.clave = ?"; $types .= 's'; $params[] = $estadoClave;
                }
            }
            $sql = $base . implode('', $conds) . " ORDER BY a.fecha DESC";
            $stmt = $conn->prepare($sql);
            if ($stmt) {
                if ($types !== '') { $stmt->bind_param($types, ...$params); }
                $stmt->execute();
                $res = $stmt->get_result();
                while ($row = $res->fetch_assoc()) { $out[] = $row; }
            }
        } else {
            // Esquema legado
            $base = "SELECT * FROM alertas WHERE 1=1";
            $conds = [];
            $types = '';
            $params = [];
            if (!empty($dia))  { $conds[] = " AND DAY(fecha) = ?"; $types .= 'i'; $params[] = (int)$dia; }
            if (!empty($mes))  { $conds[] = " AND MONTH(fecha) = ?"; $types .= 'i'; $params[] = (int)$mes; }
            if (!empty($anio)) { $conds[] = " AND YEAR(fecha) = ?"; $types .= 'i'; $params[] = (int)$anio; }
            $sql = $base . implode('', $conds) . " ORDER BY fecha DESC";
            $stmt = $conn->prepare($sql);
            if ($stmt) {
                if ($types !== '') { $stmt->bind_param($types, ...$params); }
                $stmt->execute();
                $res = $stmt->get_result();
                while ($row = $res->fetch_assoc()) { $out[] = $row; }
            }
        }
        return $out;
    }
    public static function create($mensaje, $ubicacion, $equipoId = null, $estadoClave = 'NO_ATENDIDO') {
        $conn = DB::conn();
        if (self::isNormalized()) {
            // Resolver ubicacion_id
            $uSel = $conn->prepare("SELECT id FROM ubicaciones WHERE nombre = ?");
            $uSel->bind_param('s', $ubicacion);
            $uSel->execute();
            $uid = $uSel->get_result()->fetch_assoc()['id'] ?? null;
            if (!$uid && $ubicacion) {
                $uIns = $conn->prepare("INSERT INTO ubicaciones (nombre) VALUES (?)");
                $uIns->bind_param('s', $ubicacion);
                $uIns->execute();
                $uid = $conn->insert_id;
            }
            // Resolver estado_alerta_id
            $estadoClave = strtoupper($estadoClave);
            $eSel = $conn->prepare("SELECT id FROM estados_alerta WHERE clave = ?");
            $eSel->bind_param('s', $estadoClave);
            $eSel->execute();
            $eid = $eSel->get_result()->fetch_assoc()['id'] ?? null;
            if (!$eid) return false;
            if ($equipoId) {
                $stmt = $conn->prepare('INSERT INTO alertas (mensaje, ubicacion_id, estado_alerta_id, equipo_id, fecha) VALUES (?, ?, ?, ?, NOW())');
                $stmt->bind_param('siii', $mensaje, $uid, $eid, $equipoId);
            } else {
                $stmt = $conn->prepare('INSERT INTO alertas (mensaje, ubicacion_id, estado_alerta_id, fecha) VALUES (?, ?, ?, NOW())');
                $stmt->bind_param('sii', $mensaje, $uid, $eid);
            }
            $ok = $stmt->execute();
            if ($ok) {
                $alertaId = $conn->insert_id;
                $h = $conn->prepare('INSERT INTO alertas_historial (alerta_id, estado_alerta_id, usuario) VALUES (?, ?, ?)');
                $user = Session::get('usuario') ?: null;
                if ($h) { $h->bind_param('iis', $alertaId, $eid, $user); $h->execute(); }
            }
            return $ok;
        } else {
            $stmt = $conn->prepare('INSERT INTO alertas (mensaje, ubicacion, fecha) VALUES (?, ?, NOW())');
            $stmt->bind_param('ss', $mensaje, $ubicacion);
            return $stmt->execute();
        }
    }

    public static function setEstado($alertaId, $estadoClave, $usuario = null) {
        $conn = DB::conn();
        if (!self::isNormalized()) { return false; }
        $estadoClave = strtoupper($estadoClave);
        $eSel = $conn->prepare("SELECT id FROM estados_alerta WHERE clave = ?");
        $eSel->bind_param('s', $estadoClave);
        $eSel->execute();
        $eid = $eSel->get_result()->fetch_assoc()['id'] ?? null;
        if (!$eid) return false;
        $stmt = $conn->prepare('UPDATE alertas SET estado_alerta_id = ? WHERE id = ?');
        $stmt->bind_param('ii', $eid, $alertaId);
        $ok = $stmt->execute();
        if ($ok) {
            $h = $conn->prepare('INSERT INTO alertas_historial (alerta_id, estado_alerta_id, usuario) VALUES (?, ?, ?)');
            $h->bind_param('iis', $alertaId, $eid, $usuario);
            $h->execute();
        }
        return $ok;
    }

    public static function historial($alertaId) {
        $conn = DB::conn();
        if (!self::isNormalized()) { return []; }
        $stmt = $conn->prepare("SELECT h.id, h.fecha, ea.nombre AS estado, h.usuario
                                 FROM alertas_historial h
                                 JOIN estados_alerta ea ON ea.id = h.estado_alerta_id
                                 WHERE h.alerta_id = ?
                                 ORDER BY h.fecha ASC, h.id ASC");
        $stmt->bind_param('i', $alertaId);
        $stmt->execute();
        $res = $stmt->get_result();
        $out = [];
        while ($row = $res->fetch_assoc()) { $out[] = $row; }
        return $out;
    }
}
