<?php
class Equipo {
    private static function isNormalized() {
        $conn = DB::conn();
        $res = $conn->query("SHOW TABLES LIKE 'roles'");
        return $res && $res->num_rows > 0;
    }
    public static function all() {
        $conn = DB::conn();
        if (self::isNormalized()) {
            $sql = "SELECT e.id, e.nombre, e.numero_serie, u.nombre AS ubicacion, e.fecha_registro,
                           t.numero AS numero_tarjeta_rfid
                    FROM equipos e
                    JOIN ubicaciones u ON u.id = e.ubicacion_id
                    JOIN tarjetas t ON t.id = e.tarjeta_id
                    ORDER BY e.id DESC";
        } else {
            $sql = "SELECT id, numero_tarjeta_rfid, nombre, numero_serie, ubicacion, fecha_registro FROM equipos ORDER BY id DESC";
        }
        $res = $conn->query($sql);
        $out = [];
        while ($row = $res->fetch_assoc()) { $out[] = $row; }
        return $out;
    }
    public static function create($data) {
        $conn = DB::conn();
        if (self::isNormalized()) {
            // tarjeta
            $numero = $data['numero_tarjeta_rfid'];
            $tSel = $conn->prepare("SELECT id FROM tarjetas WHERE numero = ?");
            $tSel->bind_param('s', $numero);
            $tSel->execute();
            $tid = $tSel->get_result()->fetch_assoc()['id'] ?? null;
            if (!$tid) {
                $tIns = $conn->prepare("INSERT INTO tarjetas (numero) VALUES (?)");
                $tIns->bind_param('s', $numero);
                $tIns->execute();
                $tid = $conn->insert_id;
            }
            // ubicacion
            $ubic = $data['ubicacion'];
            $uSel = $conn->prepare("SELECT id FROM ubicaciones WHERE nombre = ?");
            $uSel->bind_param('s', $ubic);
            $uSel->execute();
            $uid = $uSel->get_result()->fetch_assoc()['id'] ?? null;
            if (!$uid) {
                $uIns = $conn->prepare("INSERT INTO ubicaciones (nombre) VALUES (?)");
                $uIns->bind_param('s', $ubic);
                $uIns->execute();
                $uid = $conn->insert_id;
            }
            // insert
            $stmt = $conn->prepare("INSERT INTO equipos (nombre, numero_serie, ubicacion_id, tarjeta_id) VALUES (?, ?, ?, ?)");
            $stmt->bind_param('ssii', $data['nombre'], $data['numero_serie'], $uid, $tid);
            return $stmt->execute();
        } else {
            // esquema legado con columna numero_serie añadida por migración
            $stmt = $conn->prepare("INSERT INTO equipos (numero_tarjeta_rfid, nombre, numero_serie, ubicacion) VALUES (?, ?, ?, ?)");
            $stmt->bind_param('ssss', $data['numero_tarjeta_rfid'], $data['nombre'], $data['numero_serie'], $data['ubicacion']);
            return $stmt->execute();
        }
    }
    public static function update($id, $data) {
        $conn = DB::conn();
        if (self::isNormalized()) {
            $fields = [];$types='';$params=[];
            if (!empty($data['nombre'])) { $fields[] = 'nombre = ?'; $types.='s'; $params[] = $data['nombre']; }
            if (!empty($data['numero_serie'])) { $fields[] = 'numero_serie = ?'; $types.='s'; $params[] = $data['numero_serie']; }
            if (!empty($data['ubicacion'])) {
                $ubic = $data['ubicacion'];
                $uSel = $conn->prepare("SELECT id FROM ubicaciones WHERE nombre = ?");
                $uSel->bind_param('s', $ubic);
                $uSel->execute();
                $uid = $uSel->get_result()->fetch_assoc()['id'] ?? null;
                if (!$uid) { $uIns = $conn->prepare("INSERT INTO ubicaciones (nombre) VALUES (?)"); $uIns->bind_param('s', $ubic); $uIns->execute(); $uid = $conn->insert_id; }
                $fields[] = 'ubicacion_id = ?'; $types.='i'; $params[] = $uid;
            }
            if (!empty($data['numero_tarjeta_rfid'])) {
                $numero = $data['numero_tarjeta_rfid'];
                $tSel = $conn->prepare("SELECT id FROM tarjetas WHERE numero = ?");
                $tSel->bind_param('s', $numero);
                $tSel->execute();
                $tid = $tSel->get_result()->fetch_assoc()['id'] ?? null;
                if (!$tid) { $tIns = $conn->prepare("INSERT INTO tarjetas (numero) VALUES (?)"); $tIns->bind_param('s', $numero); $tIns->execute(); $tid = $conn->insert_id; }
                $fields[] = 'tarjeta_id = ?'; $types.='i'; $params[] = $tid;
            }
            if (empty($fields)) return false;
            $types.='i'; $params[] = $id;
            $sql = 'UPDATE equipos SET '.implode(', ',$fields).' WHERE id = ?';
            $stmt = $conn->prepare($sql);
            $stmt->bind_param($types, ...$params);
            return $stmt->execute();
        } else {
            $fields=[];$types='';$params=[];
            if (!empty($data['numero_tarjeta_rfid'])) { $fields[]='numero_tarjeta_rfid = ?'; $types.='s'; $params[]=$data['numero_tarjeta_rfid']; }
            if (!empty($data['nombre'])) { $fields[]='nombre = ?'; $types.='s'; $params[]=$data['nombre']; }
            if (!empty($data['numero_serie'])) { $fields[]='numero_serie = ?'; $types.='s'; $params[]=$data['numero_serie']; }
            if (!empty($data['ubicacion'])) { $fields[]='ubicacion = ?'; $types.='s'; $params[]=$data['ubicacion']; }
            if (empty($fields)) return false;
            $types.='i'; $params[]=$id;
            $sql = 'UPDATE equipos SET '.implode(', ',$fields).' WHERE id = ?';
            $stmt = $conn->prepare($sql);
            $stmt->bind_param($types, ...$params);
            return $stmt->execute();
        }
    }
    public static function delete($id) {
        $conn = DB::conn();
        $stmt = $conn->prepare('DELETE FROM equipos WHERE id = ?');
        $stmt->bind_param('i', $id);
        return $stmt->execute();
    }
    public static function filtered($dia, $mes, $anio) {
        $conn = DB::conn();
        if (self::isNormalized()) {
            $sql = "SELECT e.id, e.nombre, e.numero_serie, u.nombre AS ubicacion, e.fecha_registro,
                           t.numero AS numero_tarjeta_rfid
                    FROM equipos e
                    JOIN ubicaciones u ON u.id = e.ubicacion_id
                    JOIN tarjetas t ON t.id = e.tarjeta_id
                    WHERE 1=1";
        } else {
            $sql = "SELECT id, numero_tarjeta_rfid, nombre, numero_serie, ubicacion, fecha_registro FROM equipos WHERE 1=1";
        }
        if (!empty($dia)) $sql .= " AND DAY(fecha_registro) = " . intval($dia);
        if (!empty($mes)) $sql .= " AND MONTH(fecha_registro) = " . intval($mes);
        if (!empty($anio)) $sql .= " AND YEAR(fecha_registro) = " . intval($anio);
        $res = $conn->query($sql);
        $out = [];
        while ($row = $res->fetch_assoc()) { $out[] = $row; }
        return $out;
    }

    public static function findByRFID($numero) {
        $conn = DB::conn();
        if (self::isNormalized()) {
            $sql = "SELECT e.id AS equipo_id, e.nombre, e.numero_serie, u.id AS ubicacion_id, u.nombre AS ubicacion, t.numero AS numero_tarjeta_rfid
                    FROM equipos e
                    JOIN tarjetas t ON t.id = e.tarjeta_id
                    JOIN ubicaciones u ON u.id = e.ubicacion_id
                    WHERE t.numero = ? LIMIT 1";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param('s', $numero);
            $stmt->execute();
            $res = $stmt->get_result();
            return $res->fetch_assoc() ?: null;
        } else {
            $sql = "SELECT id AS equipo_id, nombre, numero_serie, ubicacion, numero_tarjeta_rfid FROM equipos WHERE numero_tarjeta_rfid = ? LIMIT 1";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param('s', $numero);
            $stmt->execute();
            $res = $stmt->get_result();
            return $res->fetch_assoc() ?: null;
        }
    }
}
