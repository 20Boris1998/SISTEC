<?php
class Usuario {
    private static function ensureRoleId($clave) {
        $conn = DB::conn();
        // Buscar role_id por clave; si no existe, crearlo
        $sel = $conn->prepare("SELECT id FROM roles WHERE clave = ?");
        $sel->bind_param('s', $clave);
        $sel->execute();
        $rid = $sel->get_result()->fetch_assoc()['id'] ?? null;
        if ($rid) return $rid;
        // Crear registro mínimo del rol
        $nombre = strtoupper($clave);
        $ins = $conn->prepare("INSERT INTO roles (clave, nombre) VALUES (?, ?)");
        $ins->bind_param('ss', $clave, $nombre);
        if ($ins->execute()) {
            return $conn->insert_id;
        }
        return null;
    }
    private static function isNormalized() {
        $conn = DB::conn();
        $hasRoles = ($conn->query("SHOW TABLES LIKE 'roles'") && $conn->query("SHOW TABLES LIKE 'roles'")->num_rows > 0);
        if (!$hasRoles) return false;
        // Debe existir role_id en usuarios para considerar modo normalizado
        $stmt = $conn->prepare("SHOW COLUMNS FROM `usuarios` LIKE 'role_id'");
        $stmt->execute();
        $res = $stmt->get_result();
        return $res && $res->num_rows > 0;
    }
    private static function hasColumn($table, $column) {
        $conn = DB::conn();
        // Algunas versiones de MariaDB/MySQL no aceptan placeholders en SHOW/DDL.
        // Sanitizar nombres y construir la consulta directamente.
        $t = preg_replace('/[^A-Za-z0-9_]/', '', (string)$table);
        $c = $conn->real_escape_string((string)$column);
        $sql = "SHOW COLUMNS FROM `{$t}` LIKE '{$c}'";
        $res = $conn->query($sql);
        return $res && $res->num_rows > 0;
    }
    private static function passwordColumnName() {
        // Determinar el nombre de columna de contraseña disponible en 'usuarios'
        if (self::hasColumn('usuarios','contrasena')) return 'contrasena';
        if (self::hasColumn('usuarios','password')) return 'password';
        if (self::hasColumn('usuarios','password_hash')) return 'password_hash';
        // Si ninguna existe (muy raro), crear 'contrasena'
        DB::conn()->query("ALTER TABLE usuarios ADD COLUMN contrasena VARCHAR(255) NOT NULL");
        return 'contrasena';
    }
    // Helpers públicos para los controladores
    public static function isNormalizedStatic() { return self::isNormalized(); }
    public static function hasColumnStatic($table, $column) { return self::hasColumn($table, $column); }
    public static function all() {
        $conn = DB::conn();
        if (self::isNormalized()) {
            $sql = "SELECT u.id, u.usuario, r.clave AS rol FROM usuarios u JOIN roles r ON r.id = u.role_id ORDER BY u.id DESC";
        } else {
            $sql = "SELECT id, usuario, rol FROM usuarios ORDER BY id DESC";
        }
        $res = $conn->query($sql);
        $out = [];
        while ($row = $res->fetch_assoc()) { $out[] = $row; }
        return $out;
    }
    public static function find($id) {
        $conn = DB::conn();
        if (self::isNormalized()) {
            $stmt = $conn->prepare("SELECT u.id, u.usuario, r.clave AS rol FROM usuarios u JOIN roles r ON r.id = u.role_id WHERE u.id = ?");
        } else {
            $stmt = $conn->prepare("SELECT id, usuario, rol FROM usuarios WHERE id = ?");
        }
        $stmt->bind_param('i', $id);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    }
    public static function existsByUsuario($usuario) {
        $conn = DB::conn();
        $stmt = $conn->prepare("SELECT id FROM usuarios WHERE usuario = ?");
        $stmt->bind_param('s', $usuario);
        $stmt->execute();
        $stmt->store_result();
        return $stmt->num_rows > 0;
    }
    public static function create($usuario, $contrasena, $rol) {
        $conn = DB::conn();
        $hash = password_hash($contrasena, PASSWORD_DEFAULT);
        $pwdCol = self::passwordColumnName();
        if (self::isNormalized()) {
            // rol es clave ('admin'|'tecnico') -> asegurar role_id
            $rid = self::ensureRoleId($rol);
            if (!$rid) return false;
            $sql = "INSERT INTO usuarios (usuario, {$pwdCol}, role_id) VALUES (?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param('ssi', $usuario, $hash, $rid);
        } else {
            // modo legado: asegurar columna 'rol' si no existe
            if (!self::hasColumn('usuarios', 'rol')) {
                $conn->query("ALTER TABLE usuarios ADD COLUMN rol VARCHAR(20) NOT NULL DEFAULT 'tecnico'");
            }
            $sql = "INSERT INTO usuarios (usuario, {$pwdCol}, rol) VALUES (?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param('sss', $usuario, $hash, $rol);
        }
        $ok = $stmt->execute();
        return ['ok' => $ok, 'err' => $ok ? '' : ($stmt->error ?? '')];
    }
    public static function update($id, $usuario = null, $contrasena = null, $rol = null) {
        $conn = DB::conn();
        $fields = [];$params = [];$types = '';
        if ($usuario !== null && $usuario !== '') { $fields[] = 'usuario = ?'; $types .= 's'; $params[] = $usuario; }
        if ($contrasena !== null && $contrasena !== '') {
            $pwdCol = self::passwordColumnName();
            $fields[] = $pwdCol . ' = ?';
            $types .= 's';
            $params[] = password_hash($contrasena, PASSWORD_DEFAULT);
        }
        if ($rol !== null && $rol !== '') {
            if (self::isNormalized()) {
                // asegurar role_id por clave
                $rid = self::ensureRoleId($rol);
                if ($rid) { $fields[] = 'role_id = ?'; $types .= 'i'; $params[] = $rid; }
            } else {
                $fields[] = 'rol = ?'; $types .= 's'; $params[] = $rol;
            }
        }
        if (empty($fields)) return ['ok'=>false,'err'=>'NO_FIELDS'];
        $types .= 'i'; $params[] = $id;
        $sql = 'UPDATE usuarios SET ' . implode(', ', $fields) . ' WHERE id = ?';
        $stmt = $conn->prepare($sql);
        $stmt->bind_param($types, ...$params);
        $ok = $stmt->execute();
        return ['ok'=>$ok, 'err'=>$ok ? '' : ($stmt->error ?? '')];
    }
    public static function delete($id) {
        $conn = DB::conn();
        $stmt = $conn->prepare('DELETE FROM usuarios WHERE id = ?');
        $stmt->bind_param('i', $id);
        return $stmt->execute();
    }
}
