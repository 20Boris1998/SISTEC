<?php
class DashboardController extends Controller {
    public function root(){
        if (!Auth::check()) { header('Location: /sistemap/public/login'); exit; }
        header('Location: /sistemap/public/dashboard');
        exit;
    }
    public function index(){
        Auth::requireLogin();
        $this->render('dashboard/index', [
            'usuario' => Session::get('usuario'),
            'rol' => Session::get('rol')
        ]);
    }
}
