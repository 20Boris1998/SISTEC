<?php
class UsuariosController extends Controller {
    private function requireRoles(array $roles) {
        Auth::requireLogin();
        $rol = Auth::role();
        if (!in_array($rol, $roles)) {
            if ($_SERVER['REQUEST_METHOD'] === 'GET') {
                header('Location: /sistemap/public/');
            } else {
                header('Content-Type: application/json');
                http_response_code(403);
                echo json_encode(['success' => false, 'error' => 'Acceso denegado']);
            }
            exit;
        }
    }

    public function index() {
        $this->requireRoles(['admin']);
        $usuarios = Usuario::all();
        $this->render('usuarios/index', [
            'usuarios' => $usuarios,
            'rol' => Auth::role(),
            'usuario' => Session::get('usuario')
        ]);
    }

    public function store() {
        try {
            $this->requireRoles(['admin']);
            header('Content-Type: application/json');
            if (!Session::validateCsrf($_POST['_csrf'] ?? '')) { http_response_code(419); echo json_encode(['success'=>false,'error'=>'Token CSRF inválido']); return; }
            $usuario = strtoupper(trim($_POST['usuario'] ?? ''));
            $contrasena = $_POST['contrasena'] ?? '';
            $rol = $_POST['rol'] ?? '';
            if ($usuario === '' || $contrasena === '' || $rol === '') { echo json_encode(['success' => false, 'error' => '⚠️ Complete todos los campos obligatorios.']); return; }
            if (!preg_match('/^[A-ZÁÉÍÓÚÑÜ]+$/u', $usuario)) { echo json_encode(['success' => false, 'error' => 'El nombre de usuario solo debe contener letras (sin espacios).']); return; }
            if (!(strlen($contrasena) >= 10 && preg_match('/[A-Za-z]/', $contrasena) && preg_match('/[0-9]/', $contrasena))) { echo json_encode(['success' => false, 'error' => 'La contraseña debe tener mínimo 10 caracteres y combinar letras y números.']); return; }
            if (!in_array($rol, ['admin','tecnico'], true)) { echo json_encode(['success'=>false,'error'=>'Rol inválido.']); return; }
            if (Usuario::existsByUsuario($usuario)) { echo json_encode(['success' => false, 'error' => 'El usuario ya existe.']); return; }
            $res = Usuario::create($usuario, $contrasena, $rol);
            $ok = is_array($res) ? ($res['ok'] ?? false) : (bool)$res;
            if ($ok) { echo json_encode(['success' => true, 'message' => '✅ Usuario agregado correctamente.']); }
            else {
                $conn = DB::conn();
                $dbErr = method_exists($conn, 'error') ? trim($conn->error) : '';
                $mErr = is_array($res) ? ($res['err'] ?? '') : '';
                $detalle = $mErr !== '' ? $mErr : $dbErr;
                echo json_encode(['success' => false, 'error' => ($detalle !== '' ? ('Error al registrar: ' . $detalle) : 'Error al registrar.')]);
            }
        } catch (Throwable $ex) {
            http_response_code(500);
            echo json_encode(['success'=>false,'error'=>'Excepción: '.$ex->getMessage()]);
        }
    }

    public function update() {
        try {
            $this->requireRoles(['admin']);
            header('Content-Type: application/json');
            if (!Session::validateCsrf($_POST['_csrf'] ?? '')) { http_response_code(419); echo json_encode(['success'=>false,'error'=>'Token CSRF inválido']); return; }
            $id = intval($_POST['id'] ?? 0);
            $usuario = $_POST['usuario'] ?? null;
            $contrasena = $_POST['contrasena'] ?? null;
            $rol = $_POST['rol'] ?? null;
        if ($id <= 0) { echo json_encode(['success'=>false,'error'=>'ID inválido']); return; }
        if ($usuario !== null && $usuario !== '') {
            $usuario = strtoupper(trim($usuario));
            if (!preg_match('/^[A-ZÁÉÍÓÚÑÜ]+$/u', $usuario)) {
                echo json_encode(['success' => false, 'error' => 'El nombre de usuario solo debe contener letras (sin espacios).']);
                return;
            }
        }
        if ($contrasena !== null && $contrasena !== '' && !(strlen($contrasena) >= 10 && preg_match('/[A-Za-z]/', $contrasena) && preg_match('/[0-9]/', $contrasena))) {
            echo json_encode(['success' => false, 'error' => 'La contraseña debe tener mínimo 10 caracteres y combinar letras y números.']);
            return;
        }
        if ($rol !== null && $rol === '') { echo json_encode(['success'=>false,'error'=>'El rol no puede estar vacío.']); return; }
        if ($rol !== null && !in_array($rol, ['admin','tecnico'], true)) { echo json_encode(['success'=>false,'error'=>'Rol inválido.']); return; }
            // En modo legado, si se envía rol y la columna no existe, crearla para compatibilidad
            if ($rol !== null && $rol !== '' && !Usuario::isNormalizedStatic() && !Usuario::hasColumnStatic('usuarios','rol')) {
                DB::conn()->query("ALTER TABLE usuarios ADD COLUMN rol VARCHAR(20) NOT NULL DEFAULT 'tecnico'");
            }
            $res = Usuario::update($id, $usuario, $contrasena, $rol);
            $ok = is_array($res) ? ($res['ok'] ?? false) : (bool)$res;
            if ($ok) { echo json_encode(['success' => true, 'message' => 'Usuario actualizado correctamente.']); }
            else {
                $conn = DB::conn();
                $dbErr = method_exists($conn, 'error') ? trim($conn->error) : '';
                $mErr = is_array($res) ? ($res['err'] ?? '') : '';
                $detalle = $mErr !== '' ? $mErr : $dbErr;
                echo json_encode(['success' => false, 'error' => ($detalle !== '' ? ('Fallo al actualizar: ' . $detalle) : 'No hay cambios o fallo al actualizar.')]);
            }
        } catch (Throwable $ex) {
            http_response_code(500);
            echo json_encode(['success'=>false,'error'=>'Excepción: '.$ex->getMessage()]);
        }
    }

    public function delete() {
        $this->requireRoles(['admin']);
        header('Content-Type: application/json');
        if (!Session::validateCsrf($_POST['_csrf'] ?? '')) { http_response_code(419); echo json_encode(['success'=>false,'error'=>'Token CSRF inválido']); return; }
        $id = intval($_POST['id'] ?? 0);
        $ok = Usuario::delete($id);
        echo json_encode($ok ? ['success' => true, 'message' => 'Usuario eliminado.'] : ['success' => false, 'error' => 'Error al eliminar.']);
    }
}
