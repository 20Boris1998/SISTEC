<?php
class AlertasController extends Controller {
    public function index() {
        Auth::requireLogin();
        $this->render('alertas/index');
    }
    public function list() {
        Auth::requireLogin();
        header('Content-Type: application/json');
        $estado = isset($_GET['estado']) ? trim($_GET['estado']) : null;
        if ($estado) {
            $data = Alerta::filtered('', '', '', $estado);
        } else {
            $data = Alerta::all();
        }
        echo json_encode(['success'=>true,'data'=>$data], JSON_UNESCAPED_UNICODE);
    }
    public function atender() {
        Auth::requireLogin();
        header('Content-Type: application/json');
        if (!Session::validateCsrf($_POST['_csrf'] ?? '')) { http_response_code(419); echo json_encode(['success'=>false,'error'=>'Token CSRF inválido']); return; }
        $id = intval($_POST['id'] ?? 0);
        if ($id <= 0) { http_response_code(400); echo json_encode(['success'=>false,'error'=>'ID inválido']); return; }
        $user = Session::get('usuario');
        $ok = Alerta::setEstado($id, 'ATENDIDO', $user);
        if ($ok) { echo json_encode(['success'=>true,'message'=>'Alerta marcada como ATENDIDA']); }
        else { http_response_code(500); echo json_encode(['success'=>false,'error'=>'No se pudo actualizar la alerta']); }
    }

    public function historial() {
        Auth::requireLogin();
        header('Content-Type: application/json');
        $id = intval($_GET['id'] ?? 0);
        if ($id <= 0) { http_response_code(400); echo json_encode(['success'=>false,'error'=>'ID inválido']); return; }
        $items = Alerta::historial($id);
        echo json_encode(['success'=>true,'data'=>$items], JSON_UNESCAPED_UNICODE);
    }

    public function revertir() {
        Auth::requireLogin();
        header('Content-Type: application/json');
        if (!Session::validateCsrf($_POST['_csrf'] ?? '')) { http_response_code(419); echo json_encode(['success'=>false,'error'=>'Token CSRF inválido']); return; }
        $id = intval($_POST['id'] ?? 0);
        if ($id <= 0) { http_response_code(400); echo json_encode(['success'=>false,'error'=>'ID inválido']); return; }
        $user = Session::get('usuario');
        $ok = Alerta::setEstado($id, 'NO_ATENDIDO', $user);
        if ($ok) { echo json_encode(['success'=>true,'message'=>'Alerta revertida a NO ATENDIDO']); }
        else { http_response_code(500); echo json_encode(['success'=>false,'error'=>'No se pudo actualizar la alerta']); }
    }
}
