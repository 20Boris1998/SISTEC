<?php
class AuthController extends Controller {
    public function showLogin(){
        if (Auth::check()) { header('Location: /sistemap/public/dashboard'); exit; }
        $this->render('auth/login', [], false);
    }

    public function login(){
        $conn = DB::conn();
        $usuario = $_POST['usuario'] ?? '';
        $contrasena = $_POST['contrasena'] ?? '';
        if (!Session::validateCsrf($_POST['_csrf'] ?? '')) {
            $this->render('auth/login', ['error' => 'Token CSRF inválido'], false);
            return;
        }
        // Detectar si existen tablas normalizadas (roles)
        $isNorm = false;
        if ($r = $conn->query("SHOW TABLES LIKE 'roles'")) { $isNorm = $r->num_rows > 0; }
        if ($isNorm) {
            $stmt = $conn->prepare('SELECT u.id, u.usuario, u.contrasena, r.clave AS rol FROM usuarios u JOIN roles r ON r.id = u.role_id WHERE u.usuario = ?');
        } else {
            $stmt = $conn->prepare('SELECT id, usuario, contrasena, rol FROM usuarios WHERE usuario = ?');
        }
        $stmt->bind_param('s', $usuario);
        $stmt->execute();
        $res = $stmt->get_result();
        if ($res && $res->num_rows === 1) {
            $u = $res->fetch_assoc();
            if (password_verify($contrasena, $u['contrasena'])) {
                Auth::login($u['usuario'], $u['rol']);
                header('Location: /sistemap/public/');
                exit;
            }
        }
        $this->render('auth/login', ['error' => 'Usuario o contraseña incorrectos'], false);
    }

    public function logout(){
        Auth::logout();
    }
}
