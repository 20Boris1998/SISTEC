<?php
class EquiposController extends Controller {
    private function requireRoles(array $roles) {
        Auth::requireLogin();
        $rol = Auth::role();
        if (!in_array($rol, $roles)) {
            if ($_SERVER['REQUEST_METHOD'] === 'GET') {
                header('Location: /sistemap/public/');
            } else {
                header('Content-Type: application/json');
                http_response_code(403);
                echo json_encode(['success' => false, 'error' => 'Acceso denegado']);
            }
            exit;
        }
    }

    public function index() {
        $this->requireRoles(['admin']);
        $equipos = Equipo::all();
        $this->render('equipos/index', [
            'equipos' => $equipos,
            'rol' => Auth::role(),
            'usuario' => Session::get('usuario')
        ]);
    }

    public function store() {
        $this->requireRoles(['admin']);
        header('Content-Type: application/json');
        if (!Session::validateCsrf($_POST['_csrf'] ?? '')) { http_response_code(419); echo json_encode(['success'=>false,'error'=>'Token CSRF inválido']); return; }
        $data = [
            'numero_tarjeta_rfid' => strtoupper(trim($_POST['numero_tarjeta_rfid'] ?? '')),
            'nombre' => strtoupper(trim($_POST['nombre'] ?? '')),
            'numero_serie' => strtoupper(trim($_POST['numero_serie'] ?? '')),
            'ubicacion' => strtoupper(trim($_POST['ubicacion'] ?? '')),
        ];
        // Validaciones
        if ($data['numero_tarjeta_rfid']==='' || $data['nombre']==='' || $data['numero_serie']==='' || $data['ubicacion']==='') {
            echo json_encode(['success'=>false,'error'=>'⚠️ Todos los campos son obligatorios.']); return;
        }
        if (!preg_match('/^[A-Z0-9]+$/', $data['numero_tarjeta_rfid'])) {
            echo json_encode(['success'=>false,'error'=>'El RFID debe ser alfanumérico (sin espacios).']); return;
        }
        // Nombre: solo letras y espacios
        if (!preg_match('/^[A-ZÁÉÍÓÚÑÜ ]+$/u', $data['nombre'])) {
            echo json_encode(['success'=>false,'error'=>'El nombre del equipo solo debe contener letras y espacios.']); return;
        }
        // Número de serie: letras, números y guiones
        if (!preg_match('/^[A-Z0-9-]+$/', $data['numero_serie'])) {
            echo json_encode(['success'=>false,'error'=>'El número de serie solo puede tener letras, números y guiones.']); return;
        }
        if (!preg_match('/^LABORATORIO\s+\d{3}$/', $data['ubicacion'])) {
            echo json_encode(['success'=>false,'error'=>'Ubicación inválida. Ejemplo válido: LABORATORIO 101']); return;
        }
        $ok = Equipo::create($data);
        echo json_encode($ok ? ['success'=>true] : ['success'=>false,'error'=>'Error al registrar.']);
    }

    public function update() {
        $this->requireRoles(['admin']);
        header('Content-Type: application/json');
        if (!Session::validateCsrf($_POST['_csrf'] ?? '')) { http_response_code(419); echo json_encode(['success'=>false,'error'=>'Token CSRF inválido']); return; }
        $id = intval($_POST['id'] ?? 0);
        $data = [
            'numero_tarjeta_rfid' => strtoupper(trim($_POST['numero_tarjeta_rfid'] ?? '')),
            'nombre' => strtoupper(trim($_POST['nombre'] ?? '')),
            'numero_serie' => strtoupper(trim($_POST['numero_serie'] ?? '')),
            'ubicacion' => strtoupper(trim($_POST['ubicacion'] ?? '')),
        ];
        if ($id<=0) { echo json_encode(['success'=>false,'error'=>'ID inválido']); return; }
        // Validaciones para actualización parcial: solo validar campos enviados (no vacíos)
        if ($data['numero_tarjeta_rfid']!=='' && !preg_match('/^[A-Z0-9]+$/', $data['numero_tarjeta_rfid'])) {
            echo json_encode(['success'=>false,'error'=>'El RFID debe ser alfanumérico (sin espacios).']); return;
        }
        if ($data['nombre']!=='' && !preg_match('/^[A-ZÁÉÍÓÚÑÜ ]+$/u', $data['nombre'])) {
            echo json_encode(['success'=>false,'error'=>'El nombre del equipo solo debe contener letras y espacios.']); return;
        }
        if ($data['numero_serie']!=='' && !preg_match('/^[A-Z0-9-]+$/', $data['numero_serie'])) {
            echo json_encode(['success'=>false,'error'=>'El número de serie solo puede tener letras, números y guiones.']); return;
        }
        if ($data['ubicacion']!=='' && !preg_match('/^LABORATORIO\s+\d{3}$/', $data['ubicacion'])) {
            echo json_encode(['success'=>false,'error'=>'Ubicación inválida. Ejemplo válido: LABORATORIO 101']); return;
        }
        // Confirmar que al menos un campo válido fue enviado
        if ($data['numero_tarjeta_rfid']==='' && $data['nombre']==='' && $data['numero_serie']==='' && $data['ubicacion']==='') {
            echo json_encode(['success'=>false,'error'=>'No hay cambios para actualizar.']); return;
        }
        $ok = Equipo::update($id, $data);
        echo json_encode($ok ? ['success'=>true] : ['success'=>false,'error'=>'Error al actualizar.']);
    }

    public function delete() {
        $this->requireRoles(['admin']);
        header('Content-Type: application/json');
        if (!Session::validateCsrf($_POST['_csrf'] ?? '')) { http_response_code(419); echo json_encode(['success'=>false,'error'=>'Token CSRF inválido']); return; }
        $id = intval($_POST['id'] ?? 0);
        if ($id<=0) { echo json_encode(['success'=>false,'error'=>'ID inválido']); return; }
        $ok = Equipo::delete($id);
        echo json_encode($ok ? ['success'=>true] : ['success'=>false,'error'=>'Error al eliminar.']);
    }
}
