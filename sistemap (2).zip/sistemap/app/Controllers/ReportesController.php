<?php
class ReportesController extends Controller {
    public function index() {
        Auth::requireLogin();
        $this->render('reportes/index');
    }

    public function equipos() {
        Auth::requireLogin();
        $dia = isset($_GET['dia']) ? intval($_GET['dia']) : '';
        $mes = isset($_GET['mes']) ? intval($_GET['mes']) : '';
        $anio = isset($_GET['anio']) ? intval($_GET['anio']) : '';
        $equipos = Equipo::filtered($dia, $mes, $anio);
        header('Content-Type: text/html; charset=utf-8');
        if (!$equipos) { echo "<tr><td colspan='5'>No hay resultados.</td></tr>"; return; }
        foreach ($equipos as $fila) {
            $laboratorio = isset($fila['ubicacion']) ? $fila['ubicacion'] : 'No especificado';
            $rfid = isset($fila['numero_tarjeta_rfid']) ? $fila['numero_tarjeta_rfid'] : '';
            $serie = isset($fila['numero_serie']) ? $fila['numero_serie'] : '';
            echo "<tr><td>" . htmlspecialchars($fila['nombre']) . "</td><td>" . htmlspecialchars($rfid) . "</td><td>" . htmlspecialchars($serie) . "</td><td>" . htmlspecialchars($fila['fecha_registro']) . "</td><td>" . htmlspecialchars($laboratorio) . "</td></tr>";
        }
    }

    public function alertas() {
        Auth::requireLogin();
        $dia = isset($_GET['dia']) ? intval($_GET['dia']) : '';
        $mes = isset($_GET['mes']) ? intval($_GET['mes']) : '';
        $anio = isset($_GET['anio']) ? intval($_GET['anio']) : '';
        $estado = isset($_GET['estado']) ? trim($_GET['estado']) : null;
        $alertas = Alerta::filtered($dia, $mes, $anio, $estado);
        header('Content-Type: text/html; charset=utf-8');
        if (!$alertas) { echo "<tr><td colspan='7'>No hay alertas registradas.</td></tr>"; return; }
        foreach ($alertas as $a) {
            $laboratorio = isset($a['ubicacion']) ? $a['ubicacion'] : 'No especificado';
            $estado = isset($a['estado_alerta']) ? $a['estado_alerta'] : 'NO ATENDIDO';
            $id = isset($a['id']) ? intval($a['id']) : 0;
            $btn = $id ? ("<button class='btn-historial' data-id='".$id."'>HISTORIAL</button>") : '';
            $serie = isset($a['numero_serie']) ? $a['numero_serie'] : '';
            $rfid = isset($a['numero_tarjeta_rfid']) ? $a['numero_tarjeta_rfid'] : '';
            echo "<tr><td>" . htmlspecialchars($a['mensaje']) . "</td><td>" . htmlspecialchars($rfid) . "</td><td>" . htmlspecialchars($serie) . "</td><td>" . htmlspecialchars($estado) . "</td><td>" . htmlspecialchars($a['fecha']) . "</td><td>" . htmlspecialchars($laboratorio) . "</td><td>".$btn."</td></tr>";
        }
    }
}
