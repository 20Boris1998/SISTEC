<?php
class ApiAlertasController extends Controller {
    public function registrar(){
        header('Content-Type: application/json');
        header('Cache-Control: no-store');
        if (function_exists('ignore_user_abort')) { ignore_user_abort(true); }
        if (session_status() === PHP_SESSION_ACTIVE) { session_write_close(); }
        $cfg = require __DIR__ . '/../../config/app.php';
        $expected = $cfg['api_key'] ?? '';
        $provided = $_SERVER['HTTP_X_API_KEY'] ?? ($_POST['api_key'] ?? '');
        if (!$expected || !is_string($provided) || !hash_equals($expected, $provided)) {
            http_response_code(401);
            echo json_encode(['success'=>false,'error'=>'No autorizado']);
            return;
        }
        $uid = strtoupper(trim($_POST['numero_tarjeta_rfid'] ?? ''));
        if ($uid === '' || !preg_match('/^[A-Z0-9]+$/', $uid)){
            http_response_code(400);
            echo json_encode(['success'=>false,'error'=>'RFID inválido']);
            return;
        }
        $equipo = Equipo::findByRFID($uid);
        $ubic = $equipo['ubicacion'] ?? 'DESCONOCIDA';
        $equipoId = isset($equipo['equipo_id']) ? (int)$equipo['equipo_id'] : null;
        if ($equipo && !empty($equipo['nombre']) && !empty($equipo['numero_serie'])) {
            $mensaje = 'EQUIPO ' . $equipo['nombre'] . ' (' . $equipo['numero_serie'] . ') EN MOVIMIENTO';
        } else {
            $mensaje = 'EQUIPO ' . $uid . ' EN MOVIMIENTO';
        }
        $ok = Alerta::create($mensaje, $ubic, $equipoId, 'NO_ATENDIDO');
        if ($ok) {
            echo json_encode(['success'=>true,'message'=>'Registrado']);
        } else {
            http_response_code(500);
            echo json_encode(['success'=>false,'error'=>'No se pudo registrar la alerta']);
        }
    }
}
