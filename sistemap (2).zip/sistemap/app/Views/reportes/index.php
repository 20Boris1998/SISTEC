<div class="container">
    <h2>📊 Reportes del Sistema</h2>

    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
        <a href="/sistemap/public/dashboard" class="btn-volver">← Volver</a>
        <button id="btn-descargar-completo" class="btn-descargar">📄 Descargar PDF Completo</button>
    </div>

    <section>
        <div style="display: flex; justify-content: space-between; align-items: center;">
            <h3>Equipos Registrados</h3>
            <button id="btn-descargar-equipos">📥 Descargar PDF</button>
        </div>

        <form id="filtro-form">
            <label for="dia">Día:</label>
            <input type="number" id="dia" name="dia" min="1" max="31" style="width: 70px;">

            <label for="mes">Mes:</label>
            <input type="number" id="mes" name="mes" min="1" max="12" style="width: 70px;">

            <label for="anio">Año:</label>
            <input type="number" id="anio" name="anio" min="2000" max="2100" style="width: 90px;">

            <button type="submit">Filtrar</button>
        </form>

        <table id="tabla-equipos">
            <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Número de Tarjeta RFID</th>
                    <th>Número de Serie</th>
                    <th>Fecha</th>
                    <th>Laboratorio</th>
                </tr>
            </thead>
            <tbody id="tabla-cuerpo-equipos"></tbody>
        </table>
    </section>

    <section style="margin-top: 40px;">
        <div style="display: flex; justify-content: space-between; align-items: center;">
            <h3>Alertas Generadas</h3>
            <button id="btn-descargar-alertas">📥 Descargar PDF</button>
        </div>
        <div style="margin:10px 0; display:flex; gap:10px; align-items:center;">
            <label for="filtro-estado-reporte">Estado:</label>
            <select id="filtro-estado-reporte">
                <option value="">TODOS</option>
                <option value="NO_ATENDIDO">NO ATENDIDO</option>
                <option value="ATENDIDO">ATENDIDO</option>
            </select>
        </div>

        <table id="tabla-alertas">
            <thead>
                <tr>
                    <th>Mensaje</th>
                    <th>Número de Tarjeta RFID</th>
                    <th>Número de Serie</th>
                    <th>Estado</th>
                    <th>Fecha</th>
                    <th>Laboratorio</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody id="tabla-cuerpo-alertas"></tbody>
        </table>
    </section>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.28/jspdf.plugin.autotable.min.js"></script>
<script src="/sistemap/public/assets/js/reportes.js?v=2"></script>

<!-- Modal Historial (Reportes) -->
<div id="historialModal" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background-color:rgba(0,0,0,0.4); z-index:9999;">
  <div style="background:white; padding:20px; border-radius:10px; width:95%; max-width:600px; margin:80px auto;">
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;">
      <h3 style="margin:0;">Historial de la alerta</h3>
      <button id="cerrarHistorial" class="modal-close" style="font-size:22px;">&times;</button>
    </div>
    <div id="historialContenido"></div>
  </div>
  </div>
