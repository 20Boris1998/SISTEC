<div class="container">
<div style="display:flex; justify-content:space-between; align-items:center; gap:10px;">
  <div>
    <h2 style="margin:0;">👤 Gestión de Usuarios</h2>
    <a href="/sistemap/public/dashboard" class="btn-volver">← Volver</a>
  </div>
  <button id="btn-descargar-usuarios" class="btn-descargar">📥 Descargar PDF</button>
</div>

<div id="mensaje-alerta" style="display:none; padding:10px; border-radius:5px; margin-top:10px; position:relative;"></div>

<?php Session::start(); $csrf = Session::csrfToken(); ?>
<form id="form-agregar-usuario" class="form-usuario" method="POST" action="/sistemap/public/usuarios/store">
    <input type="hidden" name="id" id="usuario_id">
    <input type="hidden" name="_csrf" value="<?= htmlspecialchars($csrf) ?>">
    <label for="usuario">Nombre de Usuario:<span class="req">*</span></label>
    <input class="to-upper" type="text" name="usuario" id="usuario" required pattern="[A-Za-zÁÉÍÓÚÑÜáéíóúñü]+" title="Solo letras, sin espacios" placeholder="Ej. JUANPEREZ (solo letras, sin espacios)">

    <label for="contrasena">Contraseña:<span class="req">*</span></label>
    <input type="password" name="contrasena" id="contrasena" required minlength="10" title="Mínimo 10 caracteres, combinar letras y números" placeholder="Mínimo 10, letras y números">

    <label for="rol">Rol:<span class="req">*</span></label>
    <select name="rol" id="rol" required>
        <option value="" selected disabled>Seleccione...</option>
        <option value="admin">ADMINISTRADOR</option>
        <option value="tecnico">TECNICO</option>
    </select>

    <button type="submit" id="btnGuardarUsuario">Guardar Usuario</button>
    <button type="button" id="btnCancelarUsuario" style="display:none;">Cancelar</button>
</form>

<h3>📋 Lista de Usuarios</h3>
<table id="tabla-usuarios">
    <thead>
        <tr>
            <th>ID</th>
            <th>Usuario</th>
            <th>Rol</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach (($usuarios ?? []) as $row): ?>
            <tr>
                <td><?= $row['id'] ?></td>
                <td><?= htmlspecialchars($row['usuario']) ?></td>
                <td><?= $row['rol'] === 'admin' ? 'ADMINISTRADOR' : 'TECNICO' ?></td>
                <td>
                    <?php $payload = htmlspecialchars(json_encode($row), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); ?>
                    <button type="button" class="btn-editar-usuario" data-usuario='<?= $payload ?>'>✏ Editar</button>

                    <form method="POST" action="/sistemap/public/usuarios/delete" style="display:inline" onsubmit="return false;">
                        <input type="hidden" name="id" value="<?= $row['id'] ?>">
                        <button type="submit" class="btn-eliminar-usuario">🗑 Eliminar</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
 </table>

<!-- Modal de confirmación -->
<div id="confirmModal" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background-color:rgba(0,0,0,0.4); z-index:999;">
  <div style="background:white; padding:30px; border-radius:10px; width:90%; max-width:400px; margin:100px auto; text-align:center;">
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;">
      <h3 id="modalTitle" style="margin:0;">¿Estás seguro?</h3>
      <button id="closeModalX" class="modal-close" style="font-size:22px;">&times;</button>
    </div>
    <p id="modalMessage">Esta acción no se puede deshacer.</p>
    <button id="confirmBtn" style="background-color:#28a745; color:white; border:none; padding:10px 20px; margin-right:10px; border-radius:5px;">Sí</button>
    <button id="cancelModal" style="background-color:#dc3545; color:white; border:none; padding:10px 20px; border-radius:5px;">Cancelar</button>
  </div>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.28/jspdf.plugin.autotable.min.js"></script>
 <script src="/sistemap/public/assets/js/usuarios.js"></script>
</div>
