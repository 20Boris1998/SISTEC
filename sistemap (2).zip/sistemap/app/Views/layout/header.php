<?php /* layout header */ ?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SISTEC</title>
  <link rel="stylesheet" href="/sistemap/public/assets/css/style.css">
  <?php $csrf = Session::csrfToken(); ?>
  <meta name="csrf-token" content="<?= htmlspecialchars($csrf) ?>">
</head>
<body>
  <div id="app">
    <aside class="sidebar">
      <h2>SISTEC</h2>
      <?php 
        $uri = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?? '/';
        $isActive = function(string $path) use ($uri) { return strpos($uri, $path) === 0 ? 'active' : ''; };
      ?>
      <ul>
        <li><a class="<?= $isActive('/sistemap/public/dashboard') ?>" href="/sistemap/public/dashboard">Dashboard</a></li>
        <?php if (Auth::role() === 'admin'): ?>
          <li><a class="<?= $isActive('/sistemap/public/usuarios') ?>" href="/sistemap/public/usuarios">Usuarios</a></li>
          <li><a class="<?= $isActive('/sistemap/public/equipos') ?>" href="/sistemap/public/equipos">Equipos</a></li>
        <?php endif; ?>
        <li><a class="<?= $isActive('/sistemap/public/alertas') ?>" href="/sistemap/public/alertas">Alertas</a></li>
        <li><a class="<?= $isActive('/sistemap/public/reportes') ?>" href="/sistemap/public/reportes">Reportes</a></li>
        <li><a class="<?= $isActive('/sistemap/public/logout') ?>" href="/sistemap/public/logout">Cerrar sesión</a></li>
      </ul>
    </aside>
    <main class="main-content">
