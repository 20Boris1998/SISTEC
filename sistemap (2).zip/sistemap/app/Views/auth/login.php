<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login - SISTEC</title>
  <link rel="stylesheet" href="/sistemap/public/assets/css/style.css">
  <style>
    body {
      font-family: Arial, sans-serif;
      background: linear-gradient(to right, #003366, #005580);
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      margin: 0;
    }
    .login-card {
      background-color: white;
      padding: 30px;
      border-radius: 15px;
      box-shadow: 0 8px 16px rgba(0,0,0,0.2);
      width: 320px;
      text-align: center;
    }
    .login-card h2 { margin-bottom: 18px; color: #003366; }
    .login-card input[type="text"], .login-card input[type="password"] {
      width: 100%; padding: 10px; margin-bottom: 12px; border: 1px solid #ccc; border-radius: 8px;
    }
    .login-card button { width: 100%; padding: 10px; background-color: #003366; color: white; border: none; border-radius: 8px; font-weight: bold; cursor: pointer; }
    .login-card button:hover { background-color: #005580; }
    .error { background-color: #ffdddd; color: #cc0000; border: 1px solid #cc0000; padding: 10px; margin-bottom: 12px; border-radius: 8px; }
  </style>
  </head>
<body>
  <?php require_once __DIR__ . '/../../Core/Session.php'; Session::start(); $csrf = Session::csrfToken(); ?>
  <form class="login-card" method="POST" action="/sistemap/public/login">
    <h2>🔐 Iniciar sesión</h2>
    <?php if (!empty($error)): ?>
      <div class="error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <input type="text" name="usuario" placeholder="Usuario" required>
    <input type="password" name="contrasena" placeholder="Contraseña" required>
    <input type="hidden" name="_csrf" value="<?= htmlspecialchars($csrf) ?>">
    <button type="submit">Ingresar</button>
  </form>
</body>
</html>
