<div class="container">
    <div style="display:flex; justify-content:space-between; align-items:center; gap:10px;">
      <div>
        <h2 style="margin:0;">📡 Alertas de Salida de Equipos</h2>
        <a href="/sistemap/public/dashboard" class="btn-volver">← Volver</a>
      </div>
      <button id="btn-descargar-alertas-lista" class="btn-descargar">📥 Descargar PDF</button>
    </div>

    <div style="margin:10px 0; display:flex; gap:10px; align-items:center;">
      <label for="filtro-estado-alertas">Estado:</label>
      <select id="filtro-estado-alertas">
        <option value="">TODOS</option>
        <option value="NO_ATENDIDO">NO ATENDIDO</option>
        <option value="ATENDIDO">ATENDIDO</option>
      </select>
    </div>

    <table id="tabla-alertas">
        <thead>
            <tr>
                <th>ID</th>
                <th>Mensaje</th>
                <th>Número de Tarjeta RFID</th>
                <th>Número de Serie</th>
                <th>Laboratorio</th>
                <th>Estado</th>
                <th>Fecha</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
        </tbody>
    </table>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.28/jspdf.plugin.autotable.min.js"></script>
<script src="/sistemap/public/assets/js/alertas.js?v=2"></script>

<!-- Modal Historial -->
<div id="historialModal" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background-color:rgba(0,0,0,0.4); z-index:9999;">
  <div style="background:white; padding:20px; border-radius:10px; width:95%; max-width:600px; margin:80px auto;">
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;">
      <h3 style="margin:0;">Historial de la alerta</h3>
      <button id="cerrarHistorial" class="modal-close" style="font-size:22px;">&times;</button>
    </div>
    <div id="historialContenido"></div>
    <div style="text-align:right; margin-top:10px;">
      <button id="exportarHistorialPDF">Exportar PDF</button>
    </div>
  </div>
  </div>
