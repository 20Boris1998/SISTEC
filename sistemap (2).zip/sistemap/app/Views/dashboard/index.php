<div class="container">
  <?php
    $usuarioMostrar = strtoupper((string)($usuario ?? ''));
    $rolRaw = (string)($rol ?? '');
    $rolMostrar = $rolRaw === 'admin' ? 'ADMINISTRADOR' : ($rolRaw === 'tecnico' ? 'TECNICO' : strtoupper($rolRaw));
    $rolClass = $rolRaw === 'admin' ? 'admin' : ($rolRaw === 'tecnico' ? 'tecnico' : '');
  ?>
  <div class="welcome-banner">
    <h2>👋 ¡Bienvenido, <?= htmlspecialchars($usuarioMostrar) ?>!</h2>
    <p>Este es el panel de bienvenida del sistema <strong>SISTEC</strong>.</p>
    <p>Usa el menú lateral para navegar por las secciones disponibles según tu rol: 
      <strong><?= htmlspecialchars($rolMostrar) ?></strong>.
    </p>
  </div>

  <div class="panel-box">
    <h3>Información rápida</h3>
    <ul style="margin:10px 0 0 18px; line-height:1.7;">
      <li>Gestiona usuarios y equipos desde el menú lateral.</li>
      <li>Consulta alertas en tiempo real.</li>
      <li>Genera reportes y descárgalos en PDF.</li>
    </ul>
    <div style="margin-top:16px; text-align:right;">
      <a class="btn-volver" href="/sistemap/public/logout" style="background:#e74c3c;">Cerrar sesión</a>
    </div>
  </div>
</div>
