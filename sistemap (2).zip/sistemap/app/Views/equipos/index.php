<div class="container">
    <div style="display:flex; justify-content:space-between; align-items:center; gap:10px;">
      <div>
        <h2 style="margin:0;">📟 Gestión de Equipos</h2>
        <a href="/sistemap/public/dashboard" class="btn-volver">← Volver</a>
      </div>
      <button id="btn-descargar-equipos-gestion" class="btn-descargar">📥 Descargar PDF</button>
    </div>

    <div id="mensaje-alerta" style="display:none; padding:10px; border-radius:5px; margin-top:10px; position:relative;"></div>

    <form id="formEquipo" method="POST" action="/sistemap/public/equipos/store">
        <input type="hidden" name="id" id="equipo_id">

        <label>Número de Tarjeta RFID:<span class="req">*</span></label>
        <input class="to-upper" type="text" name="numero_tarjeta_rfid" id="numero_tarjeta_rfid" required pattern="[A-Za-z0-9]+" title="Solo letras y números" placeholder="Ej. ABC123 (letras y números)">

        <label>Nombre del equipo:<span class="req">*</span></label>
        <input class="to-upper" type="text" name="nombre" id="nombre" required pattern="[A-Za-zÁÉÍÓÚÑÜáéíóúñü ]+" title="Solo letras y espacios" placeholder="Ej. MOUSE (solo letras y espacios)">

        <label>Número de Serie:<span class="req">*</span></label>
        <input class="to-upper" type="text" name="numero_serie" id="numero_serie" required pattern="[A-Za-z0-9-]+" title="Solo letras, números y guiones" placeholder="Ej. ABC-12345 (letras, números y guiones)">

        <label>Laboratorio:<span class="req">*</span></label>
        <select name="ubicacion" id="ubicacion" required>
            <option value="" selected disabled>Seleccione...</option>
            <?php
            $laboratorios = ['101','102','201','202','203','204','301','302','303','304','401','402','403','404','501','502','503','504','601','602','603','604','701','702','703','704','801','802','803','804'];
            foreach ($laboratorios as $lab) {
                echo "<option value='LABORATORIO $lab'>LABORATORIO $lab</option>";
            }
            ?>
        </select>

        <button type="submit" id="btnGuardar">Guardar Equipo</button>
        <button type="button" onclick="cancelarEdicion()" style="display:none;" id="btnCancelar">Cancelar</button>
    </form>

    <h3>📋 Lista de Equipos</h3>
    <table id="tabla-equipos-gestion">
        <thead>
            <tr>
                <th>ID</th>
                <th>Número de Tarjeta RFID</th>
                <th>Nombre</th>
                <th>Número de Serie</th>
                <th>Ubicación</th>
                <th>Fecha</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach (($equipos ?? []) as $fila): ?>
                <tr>
                    <td><?= $fila['id'] ?></td>
                    <td><?= htmlspecialchars($fila['numero_tarjeta_rfid']) ?></td>
                    <td><?= htmlspecialchars($fila['nombre']) ?></td>
                    <td><?= htmlspecialchars($fila['numero_serie'] ?? '') ?></td>
                    <td><?= htmlspecialchars($fila['ubicacion']) ?></td>
                    <td><?= htmlspecialchars($fila['fecha_registro'] ?? '') ?></td>
                    <td>
                        <?php $payload = htmlspecialchars(json_encode($fila), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); ?>
                        <button type="button" class="btn-editar-equipo" data-equipo='<?= $payload ?>'>✏ Editar</button>
                        <form method='POST' action='/sistemap/public/equipos/delete' style='display:inline' onsubmit='return false;'>
                            <input type='hidden' name='id' value='<?= $fila['id'] ?>'>
                            <button type='submit' class='btn-eliminar-equipo'>🗑 Eliminar</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
 </div>

 <div id="confirmModal" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background-color:rgba(0,0,0,0.4); z-index:999;">
  <div style="background:white; padding:30px; border-radius:10px; width:90%; max-width:400px; margin:100px auto; text-align:center;">
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;">
      <h3 id="modalTitle" style="margin:0;">¿Estás seguro?</h3>
      <button id="closeModalX" class="modal-close" style="font-size:22px;">&times;</button>
    </div>
    <p id="modalMessage">Esta acción no se puede deshacer.</p>
    <button id="confirmBtn" style="background-color:#28a745; color:white; border:none; padding:10px 20px; margin-right:10px; border-radius:5px;">Sí</button>
    <button id="cancelModal" style="background-color:#dc3545; color:white; border:none; padding:10px 20px; border-radius:5px;">Cancelar</button>
  </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.28/jspdf.plugin.autotable.min.js"></script>
<script src="/sistemap/public/assets/js/equipos.js"></script>
